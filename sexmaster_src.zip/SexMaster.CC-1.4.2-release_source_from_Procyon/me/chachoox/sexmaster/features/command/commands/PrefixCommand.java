// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.command.commands;

import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.modules.client.ClickGui;
import me.chachoox.sexmaster.features.command.Command;

public class PrefixCommand extends Command
{
    public PrefixCommand() {
        super("prefix", new String[] { "<char>" });
    }
    
    @Override
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage("§cSpecify a new prefix.");
            return;
        }
        SexMaster.moduleManager.getModuleByClass(ClickGui.class).prefix.setValue(commands[0]);
        Command.sendMessage("Prefix set to §a" + SexMaster.commandManager.getPrefix());
    }
}
