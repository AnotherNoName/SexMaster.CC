// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.misc;

import net.minecraft.entity.Entity;
import me.chachoox.sexmaster.features.command.Command;
import me.chachoox.sexmaster.SexMaster;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.chachoox.sexmaster.features.gui.SexMasterGui;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;
import me.chachoox.sexmaster.features.setting.Bind;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class MCF extends Module
{
    private final Setting<Boolean> middleClick;
    private final Setting<Boolean> keyboard;
    private final Setting<Bind> key;
    private boolean clicked;
    
    public MCF() {
        super("MCF", "Middleclick Friends.", Category.MISC, true, false, false);
        this.middleClick = (Setting<Boolean>)this.register(new Setting("MiddleClick", (T)true));
        this.keyboard = (Setting<Boolean>)this.register(new Setting("Keyboard", (T)false));
        this.key = (Setting<Bind>)this.register(new Setting("KeyBind", (T)new Bind(-1), v -> this.keyboard.getValue()));
        this.clicked = false;
    }
    
    @Override
    public void onUpdate() {
        if (Mouse.isButtonDown(2)) {
            if (!this.clicked && this.middleClick.getValue() && MCF.mc.field_71462_r == null) {
                this.onClick();
            }
            this.clicked = true;
        }
        else {
            this.clicked = false;
        }
    }
    
    @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (this.keyboard.getValue() && Keyboard.getEventKeyState() && !(MCF.mc.field_71462_r instanceof SexMasterGui) && this.key.getValue().getKey() == Keyboard.getEventKey()) {
            this.onClick();
        }
    }
    
    private void onClick() {
        final RayTraceResult result = MCF.mc.field_71476_x;
        final Entity entity;
        if (result != null && result.field_72313_a == RayTraceResult.Type.ENTITY && (entity = result.field_72308_g) instanceof EntityPlayer) {
            if (SexMaster.friendManager.isFriend(entity.func_70005_c_())) {
                SexMaster.friendManager.removeFriend(entity.func_70005_c_());
                Command.sendMessage("§c" + entity.func_70005_c_() + "§r unfriended.");
            }
            else {
                SexMaster.friendManager.addFriend(entity.func_70005_c_());
                Command.sendMessage("§b" + entity.func_70005_c_() + "§r friended.");
            }
        }
        this.clicked = true;
    }
}
