// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.misc;

import net.minecraft.item.Item;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.init.Items;
import net.minecraft.item.ItemPickaxe;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class NoEntityTrace extends Module
{
    private static NoEntityTrace INSTANCE;
    public Setting<Boolean> pick;
    public Setting<Boolean> gap;
    public Setting<Boolean> obby;
    public boolean noTrace;
    
    public NoEntityTrace() {
        super("NoEntityTrace", "Mine through entities", Category.MISC, false, false, false);
        this.pick = (Setting<Boolean>)this.register(new Setting("Pick", (T)true));
        this.gap = (Setting<Boolean>)this.register(new Setting("Gap", (T)false));
        this.obby = (Setting<Boolean>)this.register(new Setting("Obby", (T)false));
        this.setInstance();
    }
    
    public static NoEntityTrace getINSTANCE() {
        if (NoEntityTrace.INSTANCE == null) {
            NoEntityTrace.INSTANCE = new NoEntityTrace();
        }
        return NoEntityTrace.INSTANCE;
    }
    
    private void setInstance() {
        NoEntityTrace.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        final Item item = NoEntityTrace.mc.field_71439_g.func_184614_ca().func_77973_b();
        if (item instanceof ItemPickaxe && this.pick.getValue()) {
            this.noTrace = true;
            return;
        }
        if (item == Items.field_151153_ao && this.gap.getValue()) {
            this.noTrace = true;
            return;
        }
        if (item instanceof ItemBlock) {
            this.noTrace = (((ItemBlock)item).func_179223_d() == Blocks.field_150343_Z && this.obby.getValue());
            return;
        }
        this.noTrace = false;
    }
    
    static {
        NoEntityTrace.INSTANCE = new NoEntityTrace();
    }
}
