// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.misc;

import com.google.common.eventbus.Subscribe;
import me.chachoox.sexmaster.mixin.mixins.accessors.ISPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.features.modules.Module;

public class NoRotate extends Module
{
    public NoRotate() {
        super("NoRotate", "stop rotating.", Category.MISC, true, false, false);
    }
    
    @Subscribe
    public void onPacket(final PacketEvent.Receive event) {
        if (fullNullCheck()) {
            return;
        }
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            final ISPacketPlayerPosLook packet = event.getPacket();
            packet.setPitch(NoRotate.mc.field_71439_g.field_70125_A);
            packet.setYaw(NoRotate.mc.field_71439_g.field_70177_z);
        }
    }
}
