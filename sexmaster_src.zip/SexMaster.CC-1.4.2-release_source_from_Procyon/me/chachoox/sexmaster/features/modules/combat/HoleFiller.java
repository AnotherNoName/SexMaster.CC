// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.combat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Predicate;
import net.minecraft.util.NonNullList;
import me.chachoox.sexmaster.SexMaster;
import net.minecraft.init.Blocks;
import me.chachoox.sexmaster.util.EntityUtil;
import me.chachoox.sexmaster.util.RenderUtil;
import me.chachoox.sexmaster.features.modules.client.Colors;
import me.chachoox.sexmaster.event.events.Render3DEvent;
import java.util.Iterator;
import java.util.List;
import net.minecraft.util.EnumHand;
import me.chachoox.sexmaster.util.TestUtil;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.BlockEnderChest;
import me.chachoox.sexmaster.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import me.chachoox.sexmaster.event.events.PacketEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import me.chachoox.sexmaster.features.setting.Setting;
import net.minecraft.util.math.BlockPos;
import me.chachoox.sexmaster.features.modules.Module;

public class HoleFiller extends Module
{
    private static BlockPos PlayerPos;
    private Setting<Double> range;
    private Setting<Boolean> smart;
    private Setting<Integer> smartRange;
    private BlockPos render;
    private Entity renderEnt;
    private EntityPlayer closestTarget;
    private int newSlot;
    double d;
    private static boolean isSpoofingAngles;
    private static float yaw;
    private static float pitch;
    private static HoleFiller INSTANCE;
    
    public HoleFiller() {
        super("HoleFiller", "Fills holes around you.", Category.COMBAT, true, false, true);
        this.range = (Setting<Double>)this.register(new Setting("Range", (T)4.5, (T)0.1, (T)6.0));
        this.smart = (Setting<Boolean>)this.register(new Setting("Smart", (T)false));
        this.smartRange = (Setting<Integer>)this.register(new Setting("Smart Range", (T)4, (T)1, (T)6, v -> this.smart.getValue()));
        this.setInstance();
    }
    
    public static HoleFiller getInstance() {
        if (HoleFiller.INSTANCE == null) {
            HoleFiller.INSTANCE = new HoleFiller();
        }
        return HoleFiller.INSTANCE;
    }
    
    private void setInstance() {
        HoleFiller.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        final Object packet = event.getPacket();
        if (packet instanceof CPacketPlayer && HoleFiller.isSpoofingAngles) {
            ((CPacketPlayer)packet).field_149476_e = HoleFiller.yaw;
            ((CPacketPlayer)packet).field_149473_f = HoleFiller.pitch;
        }
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
    }
    
    @Override
    public void onUpdate() {
        if (HoleFiller.mc.field_71441_e == null) {
            return;
        }
        if (this.smart.getValue()) {
            this.findClosestTarget();
        }
        final List<BlockPos> blocks = this.findCrystalBlocks();
        BlockPos q = null;
        final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        final int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
        if (obbySlot == -1 && eChestSot == -1) {
            return;
        }
        final int originalSlot = HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c;
        for (final BlockPos blockPos : blocks) {
            if (!HoleFiller.mc.field_71441_e.func_72872_a((Class)Entity.class, new AxisAlignedBB(blockPos)).isEmpty()) {
                continue;
            }
            if (this.smart.getValue() && this.isInRange(blockPos)) {
                q = blockPos;
            }
            else {
                q = blockPos;
            }
        }
        this.render = q;
        if (q != null && HoleFiller.mc.field_71439_g.field_70122_E) {
            HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c = ((obbySlot == -1) ? eChestSot : obbySlot);
            HoleFiller.mc.field_71442_b.func_78765_e();
            this.lookAtPacket(q.func_177958_n() + 0.5, q.func_177956_o() - 0.5, q.func_177952_p() + 0.5, (EntityPlayer)HoleFiller.mc.field_71439_g);
            TestUtil.placeBlock(this.render);
            if (HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c != originalSlot) {
                HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
                HoleFiller.mc.field_71442_b.func_78765_e();
            }
            HoleFiller.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
            resetRotation();
        }
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.render != null) {
            RenderUtil.drawBoxESP(this.render, Colors.INSTANCE.getCurrentColor(), false, Colors.INSTANCE.getCurrentColor(), 2.0f, true, true, 150, true, -0.9, false, false, false, false, 255);
        }
    }
    
    private void lookAtPacket(final double px, final double py, final double pz, final EntityPlayer me) {
        final double[] v = EntityUtil.calculateLookAt(px, py, pz, me);
        setYawAndPitch((float)v[0], (float)v[1]);
    }
    
    private boolean IsHole(final BlockPos blockPos) {
        final BlockPos boost = blockPos.func_177982_a(0, 1, 0);
        final BlockPos boost2 = blockPos.func_177982_a(0, 0, 0);
        final BlockPos boost3 = blockPos.func_177982_a(0, 0, -1);
        final BlockPos boost4 = blockPos.func_177982_a(1, 0, 0);
        final BlockPos boost5 = blockPos.func_177982_a(-1, 0, 0);
        final BlockPos boost6 = blockPos.func_177982_a(0, 0, 1);
        final BlockPos boost7 = blockPos.func_177982_a(0, 2, 0);
        final BlockPos boost8 = blockPos.func_177963_a(0.5, 0.5, 0.5);
        final BlockPos boost9 = blockPos.func_177982_a(0, -1, 0);
        return HoleFiller.mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && HoleFiller.mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && HoleFiller.mc.field_71441_e.func_180495_p(boost7).func_177230_c() == Blocks.field_150350_a && (HoleFiller.mc.field_71441_e.func_180495_p(boost3).func_177230_c() == Blocks.field_150343_Z || HoleFiller.mc.field_71441_e.func_180495_p(boost3).func_177230_c() == Blocks.field_150357_h) && (HoleFiller.mc.field_71441_e.func_180495_p(boost4).func_177230_c() == Blocks.field_150343_Z || HoleFiller.mc.field_71441_e.func_180495_p(boost4).func_177230_c() == Blocks.field_150357_h) && (HoleFiller.mc.field_71441_e.func_180495_p(boost5).func_177230_c() == Blocks.field_150343_Z || HoleFiller.mc.field_71441_e.func_180495_p(boost5).func_177230_c() == Blocks.field_150357_h) && (HoleFiller.mc.field_71441_e.func_180495_p(boost6).func_177230_c() == Blocks.field_150343_Z || HoleFiller.mc.field_71441_e.func_180495_p(boost6).func_177230_c() == Blocks.field_150357_h) && HoleFiller.mc.field_71441_e.func_180495_p(boost8).func_177230_c() == Blocks.field_150350_a && (HoleFiller.mc.field_71441_e.func_180495_p(boost9).func_177230_c() == Blocks.field_150343_Z || HoleFiller.mc.field_71441_e.func_180495_p(boost9).func_177230_c() == Blocks.field_150357_h);
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(HoleFiller.mc.field_71439_g.field_70165_t), Math.floor(HoleFiller.mc.field_71439_g.field_70163_u), Math.floor(HoleFiller.mc.field_71439_g.field_70161_v));
    }
    
    public BlockPos getClosestTargetPos() {
        if (this.closestTarget != null) {
            return new BlockPos(Math.floor(this.closestTarget.field_70165_t), Math.floor(this.closestTarget.field_70163_u), Math.floor(this.closestTarget.field_70161_v));
        }
        return null;
    }
    
    private void findClosestTarget() {
        final List<EntityPlayer> playerList = (List<EntityPlayer>)HoleFiller.mc.field_71441_e.field_73010_i;
        this.closestTarget = null;
        for (final EntityPlayer target : playerList) {
            if (target != HoleFiller.mc.field_71439_g && !SexMaster.friendManager.isFriend(target.func_70005_c_()) && EntityUtil.isLiving((Entity)target)) {
                if (target.func_110143_aJ() <= 0.0f) {
                    continue;
                }
                if (this.closestTarget == null) {
                    this.closestTarget = target;
                }
                else {
                    if (HoleFiller.mc.field_71439_g.func_70032_d((Entity)target) >= HoleFiller.mc.field_71439_g.func_70032_d((Entity)this.closestTarget)) {
                        continue;
                    }
                    this.closestTarget = target;
                }
            }
        }
    }
    
    private boolean isInRange(final BlockPos blockPos) {
        final NonNullList positions = NonNullList.func_191196_a();
        positions.addAll((Collection)this.getSphere(getPlayerPos(), this.range.getValue().floatValue(), this.range.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::IsHole).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return positions.contains((Object)blockPos);
    }
    
    private List<BlockPos> findCrystalBlocks() {
        final NonNullList positions = NonNullList.func_191196_a();
        if (this.smart.getValue() && this.closestTarget != null) {
            positions.addAll((Collection)this.getSphere(this.getClosestTargetPos(), this.smartRange.getValue(), this.range.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::IsHole).filter((Predicate<? super Object>)this::isInRange).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        }
        else if (!this.smart.getValue()) {
            positions.addAll((Collection)this.getSphere(getPlayerPos(), this.range.getValue().floatValue(), this.range.getValue().intValue(), false, true, 0).stream().filter((Predicate<? super Object>)this::IsHole).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        }
        return (List<BlockPos>)positions;
    }
    
    public List<BlockPos> getSphere(final BlockPos loc, final float r, final int h, final boolean hollow, final boolean sphere, final int plus_y) {
        final ArrayList<BlockPos> circleblocks = new ArrayList<BlockPos>();
        final int cx = loc.func_177958_n();
        final int cy = loc.func_177956_o();
        final int cz = loc.func_177952_p();
        for (int x = cx - (int)r; x <= cx + r; ++x) {
            for (int z = cz - (int)r; z <= cz + r; ++z) {
                int y = sphere ? (cy - (int)r) : cy;
                while (true) {
                    final float f = (float)y;
                    final float f3;
                    final float f2 = f3 = (sphere ? (cy + r) : ((float)(cy + h)));
                    if (f >= f2) {
                        break;
                    }
                    final double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0);
                    if (dist < r * r && (!hollow || dist >= (r - 1.0f) * (r - 1.0f))) {
                        final BlockPos l = new BlockPos(x, y + plus_y, z);
                        circleblocks.add(l);
                    }
                    ++y;
                }
            }
        }
        return circleblocks;
    }
    
    private static void setYawAndPitch(final float yaw1, final float pitch1) {
        HoleFiller.yaw = yaw1;
        HoleFiller.pitch = pitch1;
        HoleFiller.isSpoofingAngles = true;
    }
    
    private static void resetRotation() {
        if (HoleFiller.isSpoofingAngles) {
            HoleFiller.yaw = HoleFiller.mc.field_71439_g.field_70177_z;
            HoleFiller.pitch = HoleFiller.mc.field_71439_g.field_70125_A;
            HoleFiller.isSpoofingAngles = false;
        }
    }
    
    @Override
    public void onDisable() {
        this.closestTarget = null;
        this.render = null;
        resetRotation();
        super.onDisable();
    }
    
    static {
        HoleFiller.INSTANCE = new HoleFiller();
    }
}
