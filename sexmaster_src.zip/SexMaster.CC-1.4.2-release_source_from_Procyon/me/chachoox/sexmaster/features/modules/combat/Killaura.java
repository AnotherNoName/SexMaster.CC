// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.combat;

import java.util.Iterator;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.inventory.ClickType;
import me.chachoox.sexmaster.util.InventoryUtil;
import net.minecraft.item.ItemSword;
import me.chachoox.sexmaster.util.MathUtil;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Items;
import me.chachoox.sexmaster.util.DamageUtil;
import net.minecraft.entity.player.EntityPlayer;
import me.chachoox.sexmaster.util.EntityUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.event.events.UpdateWalkingPlayerEvent;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.util.Timer;
import net.minecraft.entity.Entity;
import me.chachoox.sexmaster.features.modules.Module;

public class Killaura extends Module
{
    public static Entity target;
    private final Timer timer;
    public Setting<Float> range;
    public Setting<Boolean> autoSwitch;
    public Setting<Boolean> delay;
    public Setting<Boolean> rotate;
    public Setting<Boolean> stay;
    public Setting<Boolean> armorBreak;
    public Setting<Boolean> eating;
    public Setting<Boolean> onlySharp;
    public Setting<Boolean> teleport;
    public Setting<Float> raytrace;
    public Setting<Float> teleportRange;
    public Setting<Boolean> lagBack;
    public Setting<Boolean> players;
    public Setting<Boolean> mobs;
    public Setting<Boolean> animals;
    public Setting<Boolean> vehicles;
    public Setting<Boolean> projectiles;
    public Setting<Boolean> tps;
    public Setting<Boolean> packet;
    public Setting<Boolean> swing;
    public Setting<Boolean> sneak;
    public Setting<Boolean> info;
    private final Setting<TargetMode> targetMode;
    public Setting<Float> health;
    
    public Killaura() {
        super("Killaura", "Kills aura.", Category.COMBAT, true, false, false);
        this.timer = new Timer();
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)6.0f, (T)0.1f, (T)7.0f));
        this.autoSwitch = (Setting<Boolean>)this.register(new Setting("AutoSwitch", (T)false));
        this.delay = (Setting<Boolean>)this.register(new Setting("Delay", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.stay = (Setting<Boolean>)this.register(new Setting("Stay", (T)true, v -> this.rotate.getValue()));
        this.armorBreak = (Setting<Boolean>)this.register(new Setting("ArmorBreak", (T)false));
        this.eating = (Setting<Boolean>)this.register(new Setting("Eating", (T)true));
        this.onlySharp = (Setting<Boolean>)this.register(new Setting("Axe/Sword", (T)true));
        this.teleport = (Setting<Boolean>)this.register(new Setting("Teleport", (T)false));
        this.raytrace = (Setting<Float>)this.register(new Setting("Raytrace", (T)6.0f, (T)0.1f, (T)7.0f, v -> !this.teleport.getValue(), "Wall Range."));
        this.teleportRange = (Setting<Float>)this.register(new Setting("TpRange", (T)15.0f, (T)0.1f, (T)50.0f, v -> this.teleport.getValue(), "Teleport Range."));
        this.lagBack = (Setting<Boolean>)this.register(new Setting("LagBack", (T)true, v -> this.teleport.getValue()));
        this.players = (Setting<Boolean>)this.register(new Setting("Players", (T)true));
        this.mobs = (Setting<Boolean>)this.register(new Setting("Mobs", (T)false));
        this.animals = (Setting<Boolean>)this.register(new Setting("Animals", (T)false));
        this.vehicles = (Setting<Boolean>)this.register(new Setting("Entities", (T)false));
        this.projectiles = (Setting<Boolean>)this.register(new Setting("Projectiles", (T)false));
        this.tps = (Setting<Boolean>)this.register(new Setting("TpsSync", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
        this.swing = (Setting<Boolean>)this.register(new Setting("Swing", (T)true));
        this.sneak = (Setting<Boolean>)this.register(new Setting("State", (T)false));
        this.info = (Setting<Boolean>)this.register(new Setting("Info", (T)true));
        this.targetMode = (Setting<TargetMode>)this.register(new Setting("Target", (T)TargetMode.CLOSEST));
        this.health = (Setting<Float>)this.register(new Setting("Health", (T)6.0f, (T)0.1f, (T)36.0f, v -> this.targetMode.getValue() == TargetMode.SMART));
    }
    
    @Override
    public void onTick() {
        if (!this.rotate.getValue()) {
            this.doKillaura();
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerEvent(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0 && this.rotate.getValue()) {
            if (this.stay.getValue() && Killaura.target != null) {
                SexMaster.rotationManager.lookAtEntity(Killaura.target);
            }
            this.doKillaura();
        }
    }
    
    private void doKillaura() {
        if (this.onlySharp.getValue() && !EntityUtil.holdingWeapon((EntityPlayer)Killaura.mc.field_71439_g)) {
            Killaura.target = null;
            return;
        }
        int n = 0;
        if (this.delay.getValue()) {
            n = (int)(DamageUtil.getCooldownByWeapon((EntityPlayer)Killaura.mc.field_71439_g) * (this.tps.getValue() ? SexMaster.serverManager.getTpsFactor() : 1.0f));
        }
        final int wait = n;
        if (!this.timer.passedMs(wait) || (!this.eating.getValue() && Killaura.mc.field_71439_g.func_184587_cr() && (!Killaura.mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_185159_cQ) || Killaura.mc.field_71439_g.func_184600_cs() != EnumHand.OFF_HAND))) {
            return;
        }
        if (this.targetMode.getValue() != TargetMode.FOCUS || Killaura.target == null || (Killaura.mc.field_71439_g.func_70068_e(Killaura.target) >= MathUtil.square(this.range.getValue()) && (!this.teleport.getValue() || Killaura.mc.field_71439_g.func_70068_e(Killaura.target) >= MathUtil.square(this.teleportRange.getValue()))) || (!Killaura.mc.field_71439_g.func_70685_l(Killaura.target) && !EntityUtil.canEntityFeetBeSeen(Killaura.target) && Killaura.mc.field_71439_g.func_70068_e(Killaura.target) >= MathUtil.square(this.raytrace.getValue()) && !this.teleport.getValue())) {
            Killaura.target = this.getTarget();
        }
        if (Killaura.target == null) {
            return;
        }
        final int sword;
        if (this.autoSwitch.getValue() && (sword = InventoryUtil.findHotbarBlock(ItemSword.class)) != -1) {
            InventoryUtil.switchToHotbarSlot(sword, false);
        }
        if (this.rotate.getValue()) {
            SexMaster.rotationManager.lookAtEntity(Killaura.target);
        }
        if (this.teleport.getValue()) {
            SexMaster.positionManager.setPositionPacket(Killaura.target.field_70165_t, EntityUtil.canEntityFeetBeSeen(Killaura.target) ? Killaura.target.field_70163_u : (Killaura.target.field_70163_u + Killaura.target.func_70047_e()), Killaura.target.field_70161_v, true, true, !this.lagBack.getValue());
        }
        if (this.armorBreak.getValue()) {
            Killaura.mc.field_71442_b.func_187098_a(Killaura.mc.field_71439_g.field_71069_bz.field_75152_c, 9, Killaura.mc.field_71439_g.field_71071_by.field_70461_c, ClickType.SWAP, (EntityPlayer)Killaura.mc.field_71439_g);
            EntityUtil.attackEntity(Killaura.target, this.packet.getValue(), this.swing.getValue());
            Killaura.mc.field_71442_b.func_187098_a(Killaura.mc.field_71439_g.field_71069_bz.field_75152_c, 9, Killaura.mc.field_71439_g.field_71071_by.field_70461_c, ClickType.SWAP, (EntityPlayer)Killaura.mc.field_71439_g);
            EntityUtil.attackEntity(Killaura.target, this.packet.getValue(), this.swing.getValue());
        }
        else {
            final boolean sneaking = Killaura.mc.field_71439_g.func_70093_af();
            final boolean sprint = Killaura.mc.field_71439_g.func_70051_ag();
            if (this.sneak.getValue()) {
                if (sneaking) {
                    Killaura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)Killaura.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                }
                if (sprint) {
                    Killaura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)Killaura.mc.field_71439_g, CPacketEntityAction.Action.STOP_SPRINTING));
                }
            }
            EntityUtil.attackEntity(Killaura.target, this.packet.getValue(), this.swing.getValue());
            if (this.sneak.getValue()) {
                if (sprint) {
                    Killaura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)Killaura.mc.field_71439_g, CPacketEntityAction.Action.START_SPRINTING));
                }
                if (sneaking) {
                    Killaura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)Killaura.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                }
            }
        }
        this.timer.reset();
    }
    
    private void startEntityAttackThread(final Entity entity, final int time) {
        final Timer timer;
        new Thread(() -> {
            timer = new Timer();
            timer.reset();
            try {
                Thread.sleep(time);
            }
            catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
            EntityUtil.attackEntity(entity, true, this.swing.getValue());
        }).start();
    }
    
    private Entity getTarget() {
        Entity target = null;
        double distance = (double)(this.teleport.getValue() ? this.teleportRange.getValue() : ((double)(float)this.range.getValue()));
        double maxHealth = 36.0;
        for (final Entity entity : Killaura.mc.field_71441_e.field_72996_f) {
            if (((this.players.getValue() && entity instanceof EntityPlayer) || (this.animals.getValue() && EntityUtil.isPassive(entity)) || (this.mobs.getValue() && EntityUtil.isMobAggressive(entity)) || (this.vehicles.getValue() && EntityUtil.isVehicle(entity)) || (this.projectiles.getValue() && EntityUtil.isProjectile(entity))) && (!(entity instanceof EntityLivingBase) || !EntityUtil.isntValid(entity, distance))) {
                if (!this.teleport.getValue() && !Killaura.mc.field_71439_g.func_70685_l(entity) && !EntityUtil.canEntityFeetBeSeen(entity) && Killaura.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(this.raytrace.getValue())) {
                    continue;
                }
                if (target == null) {
                    target = entity;
                    distance = Killaura.mc.field_71439_g.func_70068_e(entity);
                    maxHealth = EntityUtil.getHealth(entity);
                }
                else {
                    if (entity instanceof EntityPlayer && DamageUtil.isArmorLow((EntityPlayer)entity, 18)) {
                        target = entity;
                        break;
                    }
                    if (this.targetMode.getValue() == TargetMode.SMART && EntityUtil.getHealth(entity) < this.health.getValue()) {
                        target = entity;
                        break;
                    }
                    if (this.targetMode.getValue() != TargetMode.HEALTH && Killaura.mc.field_71439_g.func_70068_e(entity) < distance) {
                        target = entity;
                        distance = Killaura.mc.field_71439_g.func_70068_e(entity);
                        maxHealth = EntityUtil.getHealth(entity);
                    }
                    if (this.targetMode.getValue() != TargetMode.HEALTH) {
                        continue;
                    }
                    if (EntityUtil.getHealth(entity) >= maxHealth) {
                        continue;
                    }
                    target = entity;
                    distance = Killaura.mc.field_71439_g.func_70068_e(entity);
                    maxHealth = EntityUtil.getHealth(entity);
                }
            }
        }
        return target;
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.info.getValue() && Killaura.target instanceof EntityPlayer) {
            return Killaura.target.func_70005_c_();
        }
        return null;
    }
    
    public enum TargetMode
    {
        FOCUS, 
        CLOSEST, 
        HEALTH, 
        SMART;
    }
}
