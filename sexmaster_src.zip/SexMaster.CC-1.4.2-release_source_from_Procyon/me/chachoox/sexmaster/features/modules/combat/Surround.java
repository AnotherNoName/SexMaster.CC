// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.combat;

import net.minecraft.util.EnumHand;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import me.chachoox.sexmaster.features.command.Command;
import me.chachoox.sexmaster.util.InventoryUtil;
import java.util.List;
import net.minecraft.block.state.IBlockState;
import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.util.BlockUtil;
import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.chachoox.sexmaster.util.EntityUtil;
import net.minecraft.entity.Entity;
import me.chachoox.sexmaster.util.OldEntityUtil;
import net.minecraft.init.Blocks;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import net.minecraft.util.math.Vec3d;
import java.util.Set;
import net.minecraft.util.math.BlockPos;
import me.chachoox.sexmaster.util.Timer;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class Surround extends Module
{
    private final Setting<Integer> delay;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> helpingBlocks;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> packet;
    private final Timer timer;
    private final Timer retryTimer;
    private int isSafe;
    private BlockPos startPos;
    private boolean didPlace;
    private boolean switchedItem;
    private int lastHotbarSlot;
    private boolean isSneaking;
    private int placements;
    private final Set<Vec3d> extendingBlocks;
    private int extenders;
    public static boolean isPlacing;
    private int obbySlot;
    private boolean offHand;
    private final Map<BlockPos, Integer> retries;
    private double enablePosY;
    
    public Surround() {
        super("Surround", "Surrounds you with Obsidian", Category.COMBAT, true, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)250));
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("Block/Place", (T)12, (T)1, (T)20));
        this.helpingBlocks = (Setting<Boolean>)this.register(new Setting("HelpingBlocks", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
        this.timer = new Timer();
        this.retryTimer = new Timer();
        this.didPlace = false;
        this.placements = 0;
        this.extendingBlocks = new HashSet<Vec3d>();
        this.extenders = 1;
        this.obbySlot = -1;
        this.offHand = false;
        this.retries = new HashMap<BlockPos, Integer>();
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            this.disable();
        }
        super.onEnable();
        this.enablePosY = Surround.mc.field_71439_g.field_70163_u;
        this.retries.clear();
        this.retryTimer.reset();
    }
    
    @Override
    public void onUpdate() {
        if (this.check()) {
            return;
        }
        final boolean bl;
        boolean onEChest = bl = (Surround.mc.field_71441_e.func_180495_p(new BlockPos(Surround.mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150477_bB);
        if (Surround.mc.field_71439_g.field_70163_u - (int)Surround.mc.field_71439_g.field_70163_u < 0.7) {
            onEChest = false;
        }
        if (!OldEntityUtil.isSafe((Entity)Surround.mc.field_71439_g, onEChest ? 1 : 0, false)) {
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, (int)(onEChest ? 1 : 0)), this.helpingBlocks.getValue(), false, false);
        }
        this.processExtendingBlocks();
        if (this.didPlace) {
            this.timer.reset();
        }
    }
    
    @Override
    public void onDisable() {
        if (nullCheck()) {
            return;
        }
        super.onDisable();
        Surround.isPlacing = false;
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }
    
    @Override
    public String getDisplayInfo() {
        switch (this.isSafe) {
            case 0: {
                return ChatFormatting.RED + "Unsafe";
            }
            case 1: {
                return ChatFormatting.YELLOW + "Secure";
            }
            default: {
                return ChatFormatting.GREEN + "Secure";
            }
        }
    }
    
    private void doFeetPlace() {
        if (this.check()) {
            return;
        }
        if (!OldEntityUtil.isSafe((Entity)Surround.mc.field_71439_g, 0, true)) {
            this.isSafe = 0;
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), OldEntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, 0, true), true, false, false);
        }
        else if (!OldEntityUtil.isSafe((Entity)Surround.mc.field_71439_g, -1, false)) {
            this.isSafe = 1;
            this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), OldEntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, -1, false), false, false, true);
        }
        else {
            this.isSafe = 2;
        }
        this.processExtendingBlocks();
        if (this.didPlace) {
            this.timer.reset();
        }
    }
    
    private void processExtendingBlocks() {
        if (this.extendingBlocks.size() == 2 && this.extenders < 1) {
            final Vec3d[] array = new Vec3d[2];
            int i = 0;
            final Iterator<Vec3d> iterator = this.extendingBlocks.iterator();
            while (iterator.hasNext()) {
                final Vec3d vec3d = array[i] = iterator.next();
                ++i;
            }
            final int placementsBefore = this.placements;
            if (this.areClose(array) != null) {
                this.placeBlocks(this.areClose(array), OldEntityUtil.getUnsafeBlockArrayFromVec3d(this.areClose(array), 0, true), true, false, true);
            }
            if (placementsBefore < this.placements) {
                this.extendingBlocks.clear();
            }
        }
        else if (this.extendingBlocks.size() > 2 || this.extenders >= 1) {
            this.extendingBlocks.clear();
        }
    }
    
    private Vec3d areClose(final Vec3d[] vec3ds) {
        int matches = 0;
        for (final Vec3d vec3d : vec3ds) {
            for (final Vec3d pos : OldEntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, 0, true)) {
                if (vec3d.equals((Object)pos)) {
                    ++matches;
                }
            }
        }
        if (matches == 2) {
            return Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3ds[0].func_178787_e(vec3ds[1]));
        }
        return null;
    }
    
    private boolean placeBlocks(final Vec3d pos, final Vec3d[] vec3ds, final boolean hasHelpingBlocks, final boolean isHelping, final boolean isExtending) {
        boolean gotHelp = true;
        for (final Vec3d vec3d : vec3ds) {
            gotHelp = true;
            final BlockPos position = new BlockPos(pos).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
            final IBlockState iblockstate = Surround.mc.field_71441_e.func_180495_p(Surround.mc.field_71439_g.func_180425_c());
            switch (BlockUtil.isPositionPlaceable(position, false)) {
                case 1: {
                    if (this.retries.get(position) == null || this.retries.get(position) < 4) {
                        this.placeBlock(position);
                        this.retries.put(position, (this.retries.get(position) == null) ? 1 : (this.retries.get(position) + 1));
                        this.retryTimer.reset();
                        break;
                    }
                    if (SexMaster.speedManager.getSpeedKpH() != 0.0 || isExtending) {
                        break;
                    }
                    if (this.extenders >= 1) {
                        break;
                    }
                    this.placeBlocks(Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), OldEntityUtil.getUnsafeBlockArrayFromVec3d(Surround.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), 0, true), hasHelpingBlocks, false, true);
                    this.extendingBlocks.add(vec3d);
                    ++this.extenders;
                    break;
                }
                case 2: {
                    if (!hasHelpingBlocks) {
                        break;
                    }
                    gotHelp = this.placeBlocks(pos, BlockUtil.getHelpingBlocks(vec3d), false, true, true);
                }
                case 3: {
                    if (gotHelp) {
                        this.placeBlock(position);
                    }
                    if (!isHelping) {
                        break;
                    }
                    return true;
                }
            }
        }
        return false;
    }
    
    public static Vec3d[] getUnsafeBlockArray(final Entity entity, final int height) {
        final List<Vec3d> list = BlockUtil.getUnsafeBlocks(entity, height);
        final Vec3d[] array = new Vec3d[list.size()];
        return list.toArray(array);
    }
    
    private boolean check() {
        Surround.isPlacing = false;
        this.didPlace = false;
        this.extenders = 1;
        this.placements = 0;
        this.obbySlot = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
        final int echestSlot = InventoryUtil.findHotbarBlock(Blocks.field_150477_bB);
        if (!this.isEnabled()) {
            return true;
        }
        if (Surround.mc.field_71439_g.field_70163_u > this.enablePosY) {
            this.disable();
            return true;
        }
        if (this.retryTimer.passedMs(2500L)) {
            this.retries.clear();
            this.retryTimer.reset();
        }
        if (this.obbySlot == -1 && (this.obbySlot = echestSlot) == -1) {
            Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No Obsidian in hotbar disabling...");
            this.disable();
            return true;
        }
        return !this.timer.passedMs(this.delay.getValue());
    }
    
    private void placeBlock(final BlockPos pos) {
        if (this.placements < this.blocksPerTick.getValue()) {
            final int originalSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
            final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            if (obbySlot == -1 && eChestSot == -1) {
                this.toggle();
            }
            Surround.isPlacing = true;
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = ((obbySlot == -1) ? eChestSot : obbySlot);
            Surround.mc.field_71442_b.func_78765_e();
            this.isSneaking = BlockUtil.placeBlock(pos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), this.isSneaking);
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
            Surround.mc.field_71442_b.func_78765_e();
            this.didPlace = true;
            ++this.placements;
        }
    }
    
    static {
        Surround.isPlacing = false;
    }
}
