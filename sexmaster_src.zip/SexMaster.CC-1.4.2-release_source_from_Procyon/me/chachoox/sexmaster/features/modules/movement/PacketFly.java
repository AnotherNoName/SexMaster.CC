// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.movement;

import me.chachoox.sexmaster.util.Timer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.util.math.BlockPos;
import me.chachoox.sexmaster.features.Feature;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import me.chachoox.sexmaster.event.events.PushEvent;
import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.event.events.MoveEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.chachoox.sexmaster.util.EntityUtil;
import me.chachoox.sexmaster.event.events.UpdateWalkingPlayerEvent;
import java.util.concurrent.ConcurrentHashMap;
import io.netty.util.internal.ConcurrentSet;
import me.chachoox.sexmaster.features.setting.Setting;
import java.util.Map;
import net.minecraft.network.play.client.CPacketPlayer;
import java.util.Set;
import me.chachoox.sexmaster.features.modules.Module;

public class PacketFly extends Module
{
    private static PacketFly instance;
    private final Set<CPacketPlayer> packets;
    private final Map<Integer, IDtime> teleportmap;
    public Setting<Boolean> flight;
    public Setting<Integer> flightMode;
    public Setting<Boolean> doAntiFactor;
    public Setting<Double> antiFactor;
    public Setting<Double> extraFactor;
    public Setting<Boolean> strafeFactor;
    public Setting<Integer> loops;
    public Setting<Boolean> clearTeleMap;
    public Setting<Integer> mapTime;
    public Setting<Boolean> clearIDs;
    public Setting<Boolean> setYaw;
    public Setting<Boolean> setID;
    public Setting<Boolean> setMove;
    public Setting<Boolean> nocliperino;
    public Setting<Boolean> sendTeleport;
    public Setting<Boolean> resetID;
    public Setting<Boolean> setPos;
    public Setting<Boolean> invalidPacket;
    private int flightCounter;
    private int teleportID;
    
    public PacketFly() {
        super("Packetfly", "Uses packets to fly!", Category.MOVEMENT, true, false, false);
        this.packets = (Set<CPacketPlayer>)new ConcurrentSet();
        this.teleportmap = new ConcurrentHashMap<Integer, IDtime>();
        this.flight = (Setting<Boolean>)this.register(new Setting("Flight", (T)true));
        this.flightMode = (Setting<Integer>)this.register(new Setting("FMode", (T)0, (T)0, (T)1));
        this.doAntiFactor = (Setting<Boolean>)this.register(new Setting("Factorize", (T)true));
        this.antiFactor = (Setting<Double>)this.register(new Setting("AntiFactor", (T)2.5, (T)0.1, (T)3.0));
        this.extraFactor = (Setting<Double>)this.register(new Setting("ExtraFactor", (T)1.0, (T)0.1, (T)3.0));
        this.strafeFactor = (Setting<Boolean>)this.register(new Setting("StrafeFactor", (T)true));
        this.loops = (Setting<Integer>)this.register(new Setting("Loops", (T)1, (T)1, (T)10));
        this.clearTeleMap = (Setting<Boolean>)this.register(new Setting("ClearMap", (T)true));
        this.mapTime = (Setting<Integer>)this.register(new Setting("ClearTime", (T)30, (T)1, (T)500));
        this.clearIDs = (Setting<Boolean>)this.register(new Setting("ClearIDs", (T)true));
        this.setYaw = (Setting<Boolean>)this.register(new Setting("SetYaw", (T)true));
        this.setID = (Setting<Boolean>)this.register(new Setting("SetID", (T)true));
        this.setMove = (Setting<Boolean>)this.register(new Setting("SetMove", (T)false));
        this.nocliperino = (Setting<Boolean>)this.register(new Setting("NoClip", (T)false));
        this.sendTeleport = (Setting<Boolean>)this.register(new Setting("Teleport", (T)true));
        this.resetID = (Setting<Boolean>)this.register(new Setting("ResetID", (T)true));
        this.setPos = (Setting<Boolean>)this.register(new Setting("SetPos", (T)false));
        this.invalidPacket = (Setting<Boolean>)this.register(new Setting("InvalidPacket", (T)true));
        this.flightCounter = 0;
        this.teleportID = 0;
        PacketFly.instance = this;
    }
    
    public static PacketFly getInstance() {
        if (PacketFly.instance == null) {
            PacketFly.instance = new PacketFly();
        }
        return PacketFly.instance;
    }
    
    @Override
    public void onToggle() {
    }
    
    @Override
    public void onTick() {
        this.teleportmap.entrySet().removeIf(idTime -> this.clearTeleMap.getValue() && idTime.getValue().getTimer().passedS(this.mapTime.getValue()));
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 1) {
            return;
        }
        PacketFly.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
        double speed = 0.0;
        final boolean checkCollisionBoxes = this.checkHitBoxes();
        speed = ((PacketFly.mc.field_71439_g.field_71158_b.field_78901_c && (checkCollisionBoxes || !EntityUtil.isMoving())) ? ((this.flight.getValue() && !checkCollisionBoxes) ? ((this.flightMode.getValue() == 0) ? (this.resetCounter(10) ? -0.032 : 0.062) : (this.resetCounter(20) ? -0.032 : 0.062)) : 0.062) : (PacketFly.mc.field_71439_g.field_71158_b.field_78899_d ? -0.062 : (checkCollisionBoxes ? 0.0 : (this.resetCounter(4) ? (this.flight.getValue() ? -0.04 : 0.0) : 0.0))));
        if (this.doAntiFactor.getValue() && checkCollisionBoxes && EntityUtil.isMoving() && speed != 0.0) {
            speed /= this.antiFactor.getValue();
        }
        final double[] strafing = this.getMotion((this.strafeFactor.getValue() && checkCollisionBoxes) ? 0.031 : 0.26);
        for (int i = 1; i < this.loops.getValue() + 1; ++i) {
            PacketFly.mc.field_71439_g.field_70159_w = strafing[0] * i * this.extraFactor.getValue();
            PacketFly.mc.field_71439_g.field_70181_x = speed * i;
            PacketFly.mc.field_71439_g.field_70179_y = strafing[1] * i * this.extraFactor.getValue();
            this.sendPackets(PacketFly.mc.field_71439_g.field_70159_w, PacketFly.mc.field_71439_g.field_70181_x, PacketFly.mc.field_71439_g.field_70179_y, this.sendTeleport.getValue());
        }
    }
    
    @SubscribeEvent
    public void onMove(final MoveEvent event) {
        if (this.setMove.getValue() && this.flightCounter != 0) {
            event.setX(PacketFly.mc.field_71439_g.field_70159_w);
            event.setY(PacketFly.mc.field_71439_g.field_70181_x);
            event.setZ(PacketFly.mc.field_71439_g.field_70179_y);
            if (this.nocliperino.getValue() && this.checkHitBoxes()) {
                PacketFly.mc.field_71439_g.field_70145_X = true;
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        final CPacketPlayer packet;
        if (event.getPacket() instanceof CPacketPlayer && !this.packets.remove(packet = event.getPacket())) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPushOutOfBlocks(final PushEvent event) {
        if (event.getStage() == 1) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketPlayerPosLook && !Feature.fullNullCheck()) {
            final SPacketPlayerPosLook packet = event.getPacket();
            final BlockPos pos;
            if (PacketFly.mc.field_71439_g.func_70089_S() && PacketFly.mc.field_71441_e.func_175668_a(pos = new BlockPos(PacketFly.mc.field_71439_g.field_70165_t, PacketFly.mc.field_71439_g.field_70163_u, PacketFly.mc.field_71439_g.field_70161_v), false) && !(PacketFly.mc.field_71462_r instanceof GuiDownloadTerrain) && this.clearIDs.getValue()) {
                this.teleportmap.remove(packet.func_186965_f());
            }
            if (this.setYaw.getValue()) {
                packet.field_148936_d = PacketFly.mc.field_71439_g.field_70177_z;
                packet.field_148937_e = PacketFly.mc.field_71439_g.field_70125_A;
            }
            if (this.setID.getValue()) {
                this.teleportID = packet.func_186965_f();
            }
        }
    }
    
    private boolean checkHitBoxes() {
        return !PacketFly.mc.field_71441_e.func_184144_a((Entity)PacketFly.mc.field_71439_g, PacketFly.mc.field_71439_g.func_174813_aQ().func_72321_a(-0.0625, -0.0625, -0.0625)).isEmpty();
    }
    
    private boolean resetCounter(final int counter) {
        if (++this.flightCounter >= counter) {
            this.flightCounter = 0;
            return true;
        }
        return false;
    }
    
    private double[] getMotion(final double speed) {
        float moveForward = PacketFly.mc.field_71439_g.field_71158_b.field_192832_b;
        float moveStrafe = PacketFly.mc.field_71439_g.field_71158_b.field_78902_a;
        float rotationYaw = PacketFly.mc.field_71439_g.field_70126_B + (PacketFly.mc.field_71439_g.field_70177_z - PacketFly.mc.field_71439_g.field_70126_B) * PacketFly.mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += ((moveForward > 0.0f) ? -45 : 45);
            }
            else if (moveStrafe < 0.0f) {
                rotationYaw += ((moveForward > 0.0f) ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            }
            else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        final double posX = moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
        final double posZ = moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
        return new double[] { posX, posZ };
    }
    
    private void sendPackets(final double x, final double y, final double z, final boolean teleport) {
        final Vec3d vec = new Vec3d(x, y, z);
        final Vec3d position = PacketFly.mc.field_71439_g.func_174791_d().func_178787_e(vec);
        final Vec3d outOfBoundsVec = this.outOfBoundsVec(vec, position);
        this.packetSender((CPacketPlayer)new CPacketPlayer.Position(position.field_72450_a, position.field_72448_b, position.field_72449_c, PacketFly.mc.field_71439_g.field_70122_E));
        if (this.invalidPacket.getValue()) {
            this.packetSender((CPacketPlayer)new CPacketPlayer.Position(outOfBoundsVec.field_72450_a, outOfBoundsVec.field_72448_b, outOfBoundsVec.field_72449_c, PacketFly.mc.field_71439_g.field_70122_E));
        }
        if (this.setPos.getValue()) {
            PacketFly.mc.field_71439_g.func_70107_b(position.field_72450_a, position.field_72448_b, position.field_72449_c);
        }
        this.teleportPacket(position, teleport);
    }
    
    private void teleportPacket(final Vec3d pos, final boolean shouldTeleport) {
        if (shouldTeleport) {
            PacketFly.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketConfirmTeleport(++this.teleportID));
            this.teleportmap.put(this.teleportID, new IDtime(pos, new Timer()));
        }
    }
    
    private Vec3d outOfBoundsVec(final Vec3d offset, final Vec3d position) {
        return position.func_72441_c(0.0, 1337.0, 0.0);
    }
    
    private void packetSender(final CPacketPlayer packet) {
        this.packets.add(packet);
        PacketFly.mc.field_71439_g.field_71174_a.func_147297_a((Packet)packet);
    }
    
    private void clean() {
        this.teleportmap.clear();
        this.flightCounter = 0;
        if (this.resetID.getValue()) {
            this.teleportID = 0;
        }
        this.packets.clear();
    }
    
    public static class IDtime
    {
        private final Vec3d pos;
        private final Timer timer;
        
        public IDtime(final Vec3d pos, final Timer timer) {
            this.pos = pos;
            (this.timer = timer).reset();
        }
        
        public Vec3d getPos() {
            return this.pos;
        }
        
        public Timer getTimer() {
            return this.timer;
        }
    }
}
