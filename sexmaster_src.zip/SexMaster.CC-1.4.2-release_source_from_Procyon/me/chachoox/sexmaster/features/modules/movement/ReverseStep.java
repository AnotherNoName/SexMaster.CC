// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.movement;

import net.minecraft.entity.Entity;
import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class ReverseStep extends Module
{
    private final Setting<Integer> speed;
    private final Setting<Boolean> inliquid;
    private static ReverseStep INSTANCE;
    
    public ReverseStep() {
        super("ReverseStep", "always on the bottom.", Category.MOVEMENT, true, false, false);
        this.speed = (Setting<Integer>)this.register(new Setting("Speed", (T)8, (T)1, (T)20));
        this.inliquid = (Setting<Boolean>)this.register(new Setting("Liquid", (T)false));
        this.setInstance();
    }
    
    public static ReverseStep getInstance() {
        if (ReverseStep.INSTANCE == null) {
            ReverseStep.INSTANCE = new ReverseStep();
        }
        return ReverseStep.INSTANCE;
    }
    
    private void setInstance() {
        ReverseStep.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (nullCheck()) {
            return;
        }
        if (ReverseStep.mc.field_71439_g.func_70093_af() || ReverseStep.mc.field_71439_g.field_70128_L || ReverseStep.mc.field_71439_g.field_70123_F || !ReverseStep.mc.field_71439_g.field_70122_E || (ReverseStep.mc.field_71439_g.func_70090_H() && !this.inliquid.getValue()) || (ReverseStep.mc.field_71439_g.func_180799_ab() && !this.inliquid.getValue()) || ReverseStep.mc.field_71439_g.func_70617_f_() || ReverseStep.mc.field_71474_y.field_74314_A.func_151470_d() || SexMaster.moduleManager.isModuleEnabled("Burrow") || ReverseStep.mc.field_71439_g.field_70145_X || SexMaster.moduleManager.isModuleEnabled("Packetfly") || SexMaster.moduleManager.isModuleEnabled("Strafe")) {
            return;
        }
        for (double y = 0.0; y < 90.5; y += 0.01) {
            if (!ReverseStep.mc.field_71441_e.func_184144_a((Entity)ReverseStep.mc.field_71439_g, ReverseStep.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, -y, 0.0)).isEmpty()) {
                ReverseStep.mc.field_71439_g.field_70181_x = -this.speed.getValue() / 10.0f;
                break;
            }
        }
    }
    
    static {
        ReverseStep.INSTANCE = new ReverseStep();
    }
}
