// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import org.lwjgl.input.Keyboard;
import me.chachoox.sexmaster.SexMaster;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWeb;
import me.chachoox.sexmaster.event.events.BlockCollisionBoundingBoxEvent;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class AntiWeb extends Module
{
    public Setting<Boolean> disableBB;
    public Setting<Double> bbOffset;
    public Setting<Boolean> onGround;
    public Setting<Double> motionX;
    public Setting<Double> motionY;
    
    public AntiWeb() {
        super("AntiWeb", "Modifies movement in webs.", Category.MOVEMENT, true, false, false);
        this.disableBB = (Setting<Boolean>)this.register(new Setting("AddBB", (T)true));
        this.bbOffset = (Setting<Double>)this.register(new Setting("BoxOffset", (T)0.04, (T)(-1.0), (T)1.0));
        this.onGround = (Setting<Boolean>)this.register(new Setting("OnGround", (T)true));
        this.motionX = (Setting<Double>)this.register(new Setting("MotionX", (T)0.8, (T)(-1.0), (T)5.0));
        this.motionY = (Setting<Double>)this.register(new Setting("MotionY", (T)(-0.05), (T)0.0, (T)10.0));
    }
    
    @SubscribeEvent
    public void bbEvent(final BlockCollisionBoundingBoxEvent event) {
        if (nullCheck()) {
            return;
        }
        if (AntiWeb.mc.field_71441_e.func_180495_p(event.getPos()).func_177230_c() instanceof BlockWeb && this.disableBB.getValue()) {
            event.setCanceled(true);
            event.setBoundingBox(Block.field_185505_j.func_191195_a(0.0, (double)this.bbOffset.getValue(), 0.0));
        }
    }
    
    @Override
    public void onUpdate() {
        if (AntiWeb.mc.field_71439_g.field_70134_J && !SexMaster.moduleManager.isModuleEnabled("Step")) {
            if (Keyboard.isKeyDown(AntiWeb.mc.field_71474_y.field_74311_E.field_74512_d)) {
                AntiWeb.mc.field_71439_g.field_70134_J = true;
                final EntityPlayerSP field_71439_g = AntiWeb.mc.field_71439_g;
                field_71439_g.field_70181_x *= this.motionY.getValue();
            }
            else if (this.onGround.getValue()) {
                AntiWeb.mc.field_71439_g.field_70122_E = false;
            }
            if (Keyboard.isKeyDown(AntiWeb.mc.field_71474_y.field_74351_w.field_74512_d) || Keyboard.isKeyDown(AntiWeb.mc.field_71474_y.field_74368_y.field_74512_d) || Keyboard.isKeyDown(AntiWeb.mc.field_71474_y.field_74370_x.field_74512_d) || Keyboard.isKeyDown(AntiWeb.mc.field_71474_y.field_74366_z.field_74512_d)) {
                AntiWeb.mc.field_71439_g.field_70134_J = false;
                final EntityPlayerSP field_71439_g2 = AntiWeb.mc.field_71439_g;
                field_71439_g2.field_70159_w *= this.motionX.getValue();
                final EntityPlayerSP field_71439_g3 = AntiWeb.mc.field_71439_g;
                field_71439_g3.field_70179_y *= this.motionX.getValue();
            }
        }
    }
}
