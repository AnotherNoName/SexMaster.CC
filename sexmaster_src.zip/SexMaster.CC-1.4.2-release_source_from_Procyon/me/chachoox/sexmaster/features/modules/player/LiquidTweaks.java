// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.player;

import net.minecraft.client.entity.EntityPlayerSP;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class LiquidTweaks extends Module
{
    private static LiquidTweaks INSTANCE;
    private final Setting<Boolean> vertical;
    private final Setting<Boolean> weird;
    public Setting<Boolean> solid;
    
    public LiquidTweaks() {
        super("LiquidTweaks", "Changes Liquids interaction", Category.PLAYER, false, false, false);
        this.vertical = (Setting<Boolean>)this.register(new Setting("Vertical", (T)false));
        this.weird = (Setting<Boolean>)this.register(new Setting("Weird", (T)false));
        this.solid = (Setting<Boolean>)this.register(new Setting("Solid", (T)false));
        this.setInstance();
    }
    
    public static LiquidTweaks getInstance() {
        if (LiquidTweaks.INSTANCE == null) {
            LiquidTweaks.INSTANCE = new LiquidTweaks();
        }
        return LiquidTweaks.INSTANCE;
    }
    
    private void setInstance() {
        LiquidTweaks.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (LiquidTweaks.mc.field_71439_g.func_180799_ab() && !this.weird.getValue() && this.vertical.getValue() && !LiquidTweaks.mc.field_71439_g.field_70124_G && LiquidTweaks.mc.field_71474_y.field_74311_E.func_151470_d()) {
            final EntityPlayerSP field_71439_g = LiquidTweaks.mc.field_71439_g;
            field_71439_g.field_70181_x -= 0.06553;
        }
    }
    
    static {
        LiquidTweaks.INSTANCE = new LiquidTweaks();
    }
}
