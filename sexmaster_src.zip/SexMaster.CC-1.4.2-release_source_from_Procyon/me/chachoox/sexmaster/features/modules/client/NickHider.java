// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.client;

import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.features.modules.Module;

public class NickHider extends Module
{
    private static NickHider instance;
    public final Setting<Boolean> changeOwn;
    public final Setting<String> ownName;
    private static StringBuffer name;
    
    public NickHider() {
        super("NickHider", "Hides your nick", Category.CLIENT, false, false, false);
        this.changeOwn = (Setting<Boolean>)this.register(new Setting("MyName", (T)true));
        this.ownName = (Setting<String>)this.register(new Setting("Name", (T)"Name here...", v -> this.changeOwn.getValue()));
        NickHider.instance = this;
    }
    
    public static NickHider getInstance() {
        if (NickHider.instance == null) {
            NickHider.instance = new NickHider();
        }
        return NickHider.instance;
    }
    
    public static String getPlayerName() {
        if (fullNullCheck()) {
            return NickHider.mc.func_110432_I().func_111285_a();
        }
        final String name = PlayerName();
        if (name == null || name.isEmpty()) {
            return NickHider.mc.func_110432_I().func_111285_a();
        }
        return name;
    }
    
    public static String PlayerName() {
        if (NickHider.name == null) {
            return null;
        }
        return NickHider.name.toString();
    }
    
    static {
        NickHider.name = null;
    }
}
