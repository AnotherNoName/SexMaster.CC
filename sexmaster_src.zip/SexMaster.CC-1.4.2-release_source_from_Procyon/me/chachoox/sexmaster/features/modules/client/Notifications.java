// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.client;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import me.chachoox.sexmaster.event.events.ClientEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketSpawnObject;
import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.manager.FileManager;
import java.util.Iterator;
import net.minecraft.init.SoundEvents;
import me.chachoox.sexmaster.SexMaster;
import java.util.Collection;
import me.chachoox.sexmaster.features.command.Command;
import java.util.ArrayList;
import net.minecraft.entity.player.EntityPlayer;
import me.chachoox.sexmaster.features.setting.Setting;
import me.chachoox.sexmaster.util.Timer;
import java.util.List;
import me.chachoox.sexmaster.features.modules.Module;

public class Notifications extends Module
{
    private static final String fileName = "SexMaster/util/ModuleMessage_List.txt";
    private static final List<String> modules;
    private static Notifications INSTANCE;
    private final Timer timer;
    public Setting<PopNotifier> popNotifier;
    public Setting<Boolean> totemPops;
    public Setting<Integer> delay;
    public Setting<Boolean> clearOnLogout;
    public Setting<Boolean> moduleMessage;
    public Setting<Boolean> list;
    public Setting<Boolean> watermark;
    public Setting<Boolean> visualRange;
    public Setting<Boolean> VisualRangeSound;
    public Setting<Boolean> coords;
    public Setting<Boolean> leaving;
    public Setting<Boolean> pearls;
    public Setting<Boolean> crash;
    public Timer totemAnnounce;
    private final Setting<Boolean> readfile;
    private List<EntityPlayer> knownPlayers;
    private boolean check;
    
    public Notifications() {
        super("Notifications", "Sends Messages.", Category.CLIENT, true, false, false);
        this.timer = new Timer();
        this.popNotifier = (Setting<PopNotifier>)this.register(new Setting("Mode", (T)PopNotifier.RAINBOW));
        this.totemPops = (Setting<Boolean>)this.register(new Setting("TotemPops", (T)false));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)2000, (T)0, (T)5000, v -> this.totemPops.getValue(), "Delays messages."));
        this.clearOnLogout = (Setting<Boolean>)this.register(new Setting("LogoutClear", (T)false));
        this.moduleMessage = (Setting<Boolean>)this.register(new Setting("ModuleMessage", (T)false));
        this.list = (Setting<Boolean>)this.register(new Setting("List", (T)false, v -> this.moduleMessage.getValue()));
        this.watermark = (Setting<Boolean>)this.register(new Setting("Watermark", (T)true, v -> this.moduleMessage.getValue()));
        this.visualRange = (Setting<Boolean>)this.register(new Setting("VisualRange", (T)false));
        this.VisualRangeSound = (Setting<Boolean>)this.register(new Setting("VisualRangeSound", (T)false));
        this.coords = (Setting<Boolean>)this.register(new Setting("Coords", (T)true, v -> this.visualRange.getValue()));
        this.leaving = (Setting<Boolean>)this.register(new Setting("Leaving", (T)false, v -> this.visualRange.getValue()));
        this.pearls = (Setting<Boolean>)this.register(new Setting("PearlNotifs", (T)false));
        this.crash = (Setting<Boolean>)this.register(new Setting("Crash", (T)false));
        this.totemAnnounce = new Timer();
        this.readfile = (Setting<Boolean>)this.register(new Setting("LoadFile", (T)false, v -> this.moduleMessage.getValue()));
        this.knownPlayers = new ArrayList<EntityPlayer>();
        this.setInstance();
    }
    
    public static Notifications getInstance() {
        if (Notifications.INSTANCE == null) {
            Notifications.INSTANCE = new Notifications();
        }
        return Notifications.INSTANCE;
    }
    
    public static void displayCrash(final Exception e) {
        Command.sendMessage("§cException caught: " + e.getMessage());
    }
    
    private void setInstance() {
        Notifications.INSTANCE = this;
    }
    
    @Override
    public void onLoad() {
        this.check = true;
        this.loadFile();
        this.check = false;
    }
    
    @Override
    public void onEnable() {
        this.knownPlayers = new ArrayList<EntityPlayer>();
        if (!this.check) {
            this.loadFile();
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.readfile.getValue()) {
            if (!this.check) {
                Command.sendMessage("Loading File...");
                this.timer.reset();
                this.loadFile();
            }
            this.check = true;
        }
        if (this.check && this.timer.passedMs(750L)) {
            this.readfile.setValue(false);
            this.check = false;
        }
        if (this.visualRange.getValue()) {
            final ArrayList<EntityPlayer> tickPlayerList = new ArrayList<EntityPlayer>(Notifications.mc.field_71441_e.field_73010_i);
            if (tickPlayerList.size() > 0) {
                for (final EntityPlayer player : tickPlayerList) {
                    if (!player.func_70005_c_().equals(Notifications.mc.field_71439_g.func_70005_c_())) {
                        if (this.knownPlayers.contains(player)) {
                            continue;
                        }
                        this.knownPlayers.add(player);
                        if (SexMaster.friendManager.isFriend(player)) {
                            Command.sendMessage("Player §a" + player.func_70005_c_() + "§r entered your visual range" + (this.coords.getValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"));
                        }
                        else {
                            Command.sendMessage("Player §c" + player.func_70005_c_() + "§r entered your visual range" + (this.coords.getValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"));
                        }
                        if (this.VisualRangeSound.getValue()) {
                            Notifications.mc.field_71439_g.func_184185_a(SoundEvents.field_187689_f, 1.0f, 1.0f);
                        }
                        return;
                    }
                }
            }
            if (this.knownPlayers.size() > 0) {
                for (final EntityPlayer player : this.knownPlayers) {
                    if (tickPlayerList.contains(player)) {
                        continue;
                    }
                    this.knownPlayers.remove(player);
                    if (this.leaving.getValue()) {
                        if (SexMaster.friendManager.isFriend(player)) {
                            Command.sendMessage("Player §a" + player.func_70005_c_() + "§r left your visual range" + (this.coords.getValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"));
                        }
                        else {
                            Command.sendMessage("Player §c" + player.func_70005_c_() + "§r left your visual range" + (this.coords.getValue() ? (" at (" + (int)player.field_70165_t + ", " + (int)player.field_70163_u + ", " + (int)player.field_70161_v + ")!") : "!"));
                        }
                    }
                }
            }
        }
    }
    
    public void loadFile() {
        final List<String> fileInput = FileManager.readTextFileAllLines("SexMaster/util/ModuleMessage_List.txt");
        final Iterator<String> i = fileInput.iterator();
        Notifications.modules.clear();
        while (i.hasNext()) {
            final String s = i.next();
            if (s.replaceAll("\\s", "").isEmpty()) {
                continue;
            }
            Notifications.modules.add(s);
        }
    }
    
    @SubscribeEvent
    public void onReceivePacket(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketSpawnObject && this.pearls.getValue()) {
            final SPacketSpawnObject packet = event.getPacket();
            final EntityPlayer player = Notifications.mc.field_71441_e.func_184137_a(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e(), 1.0, false);
            if (player == null) {
                return;
            }
            if (packet.func_149001_c() == 85) {
                Command.sendMessage("§cPearl thrown by " + player.func_70005_c_() + " at X:" + (int)packet.func_186880_c() + " Y:" + (int)packet.func_186882_d() + " Z:" + (int)packet.func_186881_e());
            }
        }
    }
    
    @SubscribeEvent
    public void onToggleModule(final ClientEvent event) {
        if (!this.moduleMessage.getValue()) {
            return;
        }
        Module module;
        if (event.getStage() == 0 && !(module = (Module)event.getFeature()).equals(this) && (Notifications.modules.contains(module.getDisplayName()) || !this.list.getValue())) {
            int moduleNumber = 0;
            for (final char character : module.getDisplayName().toCharArray()) {
                moduleNumber += character;
                moduleNumber *= 10;
            }
            if (this.watermark.getValue()) {
                final TextComponentString textComponentString = new TextComponentString(SexMaster.commandManager.getClientMessage() + " §r§l" + module.getDisplayName() + "§r§c disabled.");
                Notifications.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
            }
            else {
                final TextComponentString textComponentString = new TextComponentString("§l" + module.getDisplayName() + "§r§c disabled.");
                Notifications.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
            }
        }
        if (event.getStage() == 1 && (Notifications.modules.contains((module = (Module)event.getFeature()).getDisplayName()) || !this.list.getValue())) {
            int moduleNumber = 0;
            for (final char character : module.getDisplayName().toCharArray()) {
                moduleNumber += character;
                moduleNumber *= 10;
            }
            if (this.watermark.getValue()) {
                final TextComponentString textComponentString = new TextComponentString(SexMaster.commandManager.getClientMessage() + " §r§l" + module.getDisplayName() + "§r§a enabled.");
                Notifications.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
            }
            else {
                final TextComponentString textComponentString = new TextComponentString("§l" + module.getDisplayName() + "§r§a enabled.");
                Notifications.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)textComponentString, moduleNumber);
            }
        }
    }
    
    static {
        modules = new ArrayList<String>();
        Notifications.INSTANCE = new Notifications();
    }
    
    public enum PopNotifier
    {
        RAINBOW, 
        SEXMASTER;
    }
}
