// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.modules.client;

import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraftforge.fml.client.GuiModList;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.gui.GuiConfirmOpenLink;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiContainer;
import me.chachoox.sexmaster.util.Util;
import me.chachoox.sexmaster.features.modules.Module;

public class GuiBlur extends Module implements Util
{
    public GuiBlur() {
        super("GUIBlur", "nigga", Category.CLIENT, true, false, false);
    }
    
    @Override
    public void onDisable() {
        if (GuiBlur.mc.field_71441_e != null) {
            GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
        }
    }
    
    @Override
    public void onUpdate() {
        if (GuiBlur.mc.field_71441_e == null) {
            return;
        }
        if (!ClickGui.getInstance().isEnabled() && !(GuiBlur.mc.field_71462_r instanceof GuiContainer) && !(GuiBlur.mc.field_71462_r instanceof GuiChat) && !(GuiBlur.mc.field_71462_r instanceof GuiConfirmOpenLink) && !(GuiBlur.mc.field_71462_r instanceof GuiEditSign) && !(GuiBlur.mc.field_71462_r instanceof GuiGameOver) && !(GuiBlur.mc.field_71462_r instanceof GuiOptions) && !(GuiBlur.mc.field_71462_r instanceof GuiIngameMenu) && !(GuiBlur.mc.field_71462_r instanceof GuiVideoSettings) && !(GuiBlur.mc.field_71462_r instanceof GuiScreenOptionsSounds) && !(GuiBlur.mc.field_71462_r instanceof GuiControls) && !(GuiBlur.mc.field_71462_r instanceof GuiCustomizeSkin) && !(GuiBlur.mc.field_71462_r instanceof GuiModList)) {
            if (GuiBlur.mc.field_71460_t.func_147706_e() == null) {
                return;
            }
            GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
        }
        else {
            if (OpenGlHelper.field_148824_g && GuiBlur.mc.func_175606_aa() instanceof EntityPlayer) {
                if (GuiBlur.mc.field_71460_t.func_147706_e() != null) {
                    GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
                }
                try {
                    GuiBlur.mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
                    return;
                }
                catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            }
            if (GuiBlur.mc.field_71460_t.func_147706_e() == null) {
                return;
            }
            if (GuiBlur.mc.field_71462_r != null) {
                return;
            }
            GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
        }
    }
}
