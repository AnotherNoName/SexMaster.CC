// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.gui;

import java.io.IOException;
import org.lwjgl.input.Mouse;
import net.minecraft.client.gui.ScaledResolution;
import me.chachoox.sexmaster.features.modules.client.ClickGui;
import org.lwjgl.opengl.GL11;
import me.chachoox.sexmaster.features.gui.components.items.Item;
import java.util.Iterator;
import me.chachoox.sexmaster.features.gui.components.items.buttons.Button;
import me.chachoox.sexmaster.features.gui.components.items.buttons.ModuleButton;
import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.SexMaster;
import java.util.Random;
import me.chachoox.sexmaster.features.gui.effect.Particle.ParticleSystem;
import me.chachoox.sexmaster.features.gui.effect.Snow;
import me.chachoox.sexmaster.features.gui.components.Component;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiScreen;

public class SexMasterGui extends GuiScreen
{
    private static SexMasterGui SexMasterGui;
    private static SexMasterGui INSTANCE;
    private final ArrayList<Component> components;
    private ArrayList<Snow> _snowList;
    public ParticleSystem particleSystem;
    
    public SexMasterGui() {
        this.components = new ArrayList<Component>();
        this._snowList = new ArrayList<Snow>();
        this.setInstance();
        this.load();
    }
    
    public static SexMasterGui getInstance() {
        if (me.chachoox.sexmaster.features.gui.SexMasterGui.INSTANCE == null) {
            me.chachoox.sexmaster.features.gui.SexMasterGui.INSTANCE = new SexMasterGui();
        }
        return me.chachoox.sexmaster.features.gui.SexMasterGui.INSTANCE;
    }
    
    public static SexMasterGui getClickGui() {
        return getInstance();
    }
    
    private void setInstance() {
        me.chachoox.sexmaster.features.gui.SexMasterGui.INSTANCE = this;
    }
    
    private void load() {
        final Random random = new Random();
        for (int i = 0; i < 100; ++i) {
            for (int y = 0; y < 3; ++y) {
                final Snow snow = new Snow(25 * i, y * -50, random.nextInt(3) + 1, random.nextInt(2) + 1);
                this._snowList.add(snow);
            }
        }
        int x = -80;
        for (final Module.Category category : SexMaster.moduleManager.getCategories()) {
            final ArrayList<Component> components2 = this.components;
            final String name = category.getName();
            x += 100;
            components2.add(new Component(name, x, 10, true) {
                @Override
                public void setupItems() {
                    SexMaster.moduleManager.getModulesByCategory(category).forEach(module -> {
                        if (!module.hidden) {
                            this.addButton(new ModuleButton(module));
                        }
                    });
                }
            });
        }
        this.components.forEach(components -> components.getItems().sort((item1, item2) -> item1.getName().compareTo(item2.getName())));
    }
    
    public void updateModule(final Module module) {
        for (final Component component : this.components) {
            for (final Item item : component.getItems()) {
                if (!(item instanceof ModuleButton)) {
                    continue;
                }
                final ModuleButton button = (ModuleButton)item;
                final Module mod = button.getModule();
                if (module == null) {
                    continue;
                }
                if (!module.equals(mod)) {
                    continue;
                }
                button.initSettings();
                break;
            }
        }
    }
    
    public static void drawCompleteImage(final int posX, final int posY, final int width, final int height) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)posX, (float)posY, 0.0f);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(0.0f, 0.0f, 0.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(0.0f, (float)height, 0.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f((float)width, (float)height, 0.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f((float)width, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glPopMatrix();
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        if (ClickGui.getInstance().dark.getValue()) {
            this.func_146276_q_();
        }
        final ScaledResolution res = new ScaledResolution(this.field_146297_k);
        this.checkMouseWheel();
        this.components.forEach(components -> components.drawScreen(mouseX, mouseY, partialTicks));
        if (!this._snowList.isEmpty() && ClickGui.getInstance().snowing.getValue()) {
            this._snowList.forEach(snow -> snow.Update(res));
        }
        if (this.particleSystem != null && ClickGui.getInstance().particles.getValue()) {
            this.particleSystem.render(mouseX, mouseY);
        }
        else {
            this.particleSystem = new ParticleSystem(new ScaledResolution(this.field_146297_k));
        }
    }
    
    public void func_73864_a(final int mouseX, final int mouseY, final int clickedButton) {
        this.components.forEach(components -> components.mouseClicked(mouseX, mouseY, clickedButton));
    }
    
    public void func_146286_b(final int mouseX, final int mouseY, final int releaseButton) {
        this.components.forEach(components -> components.mouseReleased(mouseX, mouseY, releaseButton));
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    public final ArrayList<Component> getComponents() {
        return this.components;
    }
    
    public void checkMouseWheel() {
        final int dWheel = Mouse.getDWheel();
        if (dWheel < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        }
        else if (dWheel > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
    }
    
    public int getTextOffset() {
        return -6;
    }
    
    public Component getComponentByName(final String name) {
        for (final Component component : this.components) {
            if (!component.getName().equalsIgnoreCase(name)) {
                continue;
            }
            return component;
        }
        return null;
    }
    
    public void func_73869_a(final char typedChar, final int keyCode) throws IOException {
        super.func_73869_a(typedChar, keyCode);
        this.components.forEach(component -> component.onKeyTyped(typedChar, keyCode));
    }
    
    public void func_73876_c() {
        if (this.particleSystem != null) {
            this.particleSystem.update();
        }
    }
    
    static {
        me.chachoox.sexmaster.features.gui.SexMasterGui.INSTANCE = new SexMasterGui();
    }
}
