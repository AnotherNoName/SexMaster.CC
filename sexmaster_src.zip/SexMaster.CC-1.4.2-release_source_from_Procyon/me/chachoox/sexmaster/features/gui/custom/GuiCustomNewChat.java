// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.features.gui.custom;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiNewChat;

public class GuiCustomNewChat extends GuiNewChat
{
    public GuiCustomNewChat(final Minecraft mcIn) {
        super(mcIn);
    }
}
