// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.manager;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.chachoox.sexmaster.SexMaster;
import net.minecraft.network.play.client.CPacketChatMessage;
import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.features.command.Command;
import net.minecraftforge.common.MinecraftForge;
import me.chachoox.sexmaster.features.Feature;

public class ReloadManager extends Feature
{
    public String prefix;
    
    public void init(final String prefix) {
        this.prefix = prefix;
        MinecraftForge.EVENT_BUS.register((Object)this);
        if (!Feature.fullNullCheck()) {
            Command.sendMessage("§cPhobos has been unloaded. Type " + prefix + "reload to reload.");
        }
    }
    
    public void unload() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        final CPacketChatMessage packet;
        if (event.getPacket() instanceof CPacketChatMessage && (packet = event.getPacket()).func_149439_c().startsWith(this.prefix) && packet.func_149439_c().contains("reload")) {
            SexMaster.load();
            event.setCanceled(true);
        }
    }
}
