// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster.manager;

import java.util.function.BiFunction;
import me.chachoox.sexmaster.SexMaster;
import java.util.Iterator;
import me.chachoox.sexmaster.features.command.Command;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import me.chachoox.sexmaster.features.modules.client.Notifications;
import me.chachoox.sexmaster.features.Feature;

public class TotemPopManager extends Feature
{
    private Notifications notifications;
    private Map<EntityPlayer, Integer> poplist;
    private final Set<EntityPlayer> toAnnounce;
    
    public TotemPopManager() {
        this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
        this.toAnnounce = new HashSet<EntityPlayer>();
    }
    
    public void onUpdate() {
        if (this.notifications.totemAnnounce.passedMs(this.notifications.delay.getValue()) && this.notifications.isOn() && this.notifications.totemPops.getValue()) {
            for (final EntityPlayer player : this.toAnnounce) {
                if (player == null) {
                    continue;
                }
                int playerNumber = 0;
                for (final char character : player.func_70005_c_().toCharArray()) {
                    playerNumber += character;
                    playerNumber *= 10;
                }
                Command.sendOverwriteMessage(this.Pop(player), playerNumber);
                this.toAnnounce.remove(player);
                this.notifications.totemAnnounce.reset();
                break;
            }
        }
    }
    
    public String Pop(final EntityPlayer player) {
        if (this.getTotemPops(player) == 1) {
            if (Notifications.getInstance().isEnabled()) {
                switch (Notifications.getInstance().popNotifier.getValue()) {
                    case RAINBOW: {
                        final String text = "§+" + player.func_70005_c_() + " popped " + this.getTotemPops(player) + " totem.";
                        return text;
                    }
                    case SEXMASTER: {
                        final String text = "§5[§dSexMaster.CC§5] §b" + player.func_70005_c_() + "§d popped §b" + this.getTotemPops(player) + "§d totem.";
                        return text;
                    }
                }
            }
        }
        else if (Notifications.getInstance().isEnabled()) {
            switch (Notifications.getInstance().popNotifier.getValue()) {
                case RAINBOW: {
                    final String text = "§+" + player.func_70005_c_() + " popped " + this.getTotemPops(player) + " totems.";
                    return text;
                }
                case SEXMASTER: {
                    final String text = "§5[§dSexMaster.CC§5] §b" + player.func_70005_c_() + "§d popped §b" + this.getTotemPops(player) + "§d totems.";
                    return text;
                }
            }
        }
        return "";
    }
    
    public void onLogout() {
        this.onOwnLogout(this.notifications.clearOnLogout.getValue());
    }
    
    public void init() {
        this.notifications = SexMaster.moduleManager.getModuleByClass(Notifications.class);
    }
    
    public void onTotemPop(final EntityPlayer player) {
        this.popTotem(player);
        if (!player.equals((Object)TotemPopManager.mc.field_71439_g)) {
            this.toAnnounce.add(player);
            this.notifications.totemAnnounce.reset();
        }
    }
    
    public String deathPop(final EntityPlayer player) {
        if (this.getTotemPops(player) == 1) {
            if (Notifications.getInstance().isEnabled()) {
                switch (Notifications.getInstance().popNotifier.getValue()) {
                    case RAINBOW: {
                        final String text = "§+" + player.func_70005_c_() + " died after popping " + this.getTotemPops(player) + " totem.";
                        return text;
                    }
                    case SEXMASTER: {
                        final String text = "§5[§dSexMaster.CC§5] §b" + player.func_70005_c_() + "§d died after popping §b" + this.getTotemPops(player) + "§d totem.";
                        return text;
                    }
                }
            }
        }
        else if (Notifications.getInstance().isEnabled()) {
            switch (Notifications.getInstance().popNotifier.getValue()) {
                case RAINBOW: {
                    final String text = "§+" + player.func_70005_c_() + " died after popping " + this.getTotemPops(player) + " totems.";
                    return text;
                }
                case SEXMASTER: {
                    final String text = "§5[§dSexMaster.CC§5] §b" + player.func_70005_c_() + "§d died after popping §b" + this.getTotemPops(player) + "§d totems.";
                    return text;
                }
            }
        }
        return null;
    }
    
    public void onDeath(final EntityPlayer player) {
        if (this.getTotemPops(player) != 0 && !player.equals((Object)TotemPopManager.mc.field_71439_g) && this.notifications.isOn() && this.notifications.totemPops.getValue()) {
            int playerNumber = 0;
            for (final char character : player.func_70005_c_().toCharArray()) {
                playerNumber += character;
                playerNumber *= 10;
            }
            Command.sendOverwriteMessage(this.deathPop(player), playerNumber);
            this.toAnnounce.remove(player);
        }
        this.resetPops(player);
    }
    
    public void onLogout(final EntityPlayer player, final boolean clearOnLogout) {
        if (clearOnLogout) {
            this.resetPops(player);
        }
    }
    
    public void onOwnLogout(final boolean clearOnLogout) {
        if (clearOnLogout) {
            this.clearList();
        }
    }
    
    public void clearList() {
        this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
    }
    
    public void resetPops(final EntityPlayer player) {
        this.setTotemPops(player, 0);
    }
    
    public void popTotem(final EntityPlayer player) {
        this.poplist.merge(player, 1, Integer::sum);
    }
    
    public void setTotemPops(final EntityPlayer player, final int amount) {
        this.poplist.put(player, amount);
    }
    
    public int getTotemPops(final EntityPlayer player) {
        final Integer pops = this.poplist.get(player);
        if (pops == null) {
            return 0;
        }
        return pops;
    }
    
    public String getTotemPopString(final EntityPlayer player) {
        return "§f" + ((this.getTotemPops(player) <= 0) ? "" : ("-" + this.getTotemPops(player) + " "));
    }
}
