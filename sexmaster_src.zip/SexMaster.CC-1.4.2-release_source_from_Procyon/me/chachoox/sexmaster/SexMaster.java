// 
// Decompiled by Procyon v0.5.36
// 

package me.chachoox.sexmaster;

import org.apache.logging.log4j.LogManager;
import org.lwjgl.opengl.Display;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import me.chachoox.sexmaster.features.modules.client.RPC;
import me.chachoox.sexmaster.manager.SafetyManager;
import me.chachoox.sexmaster.manager.HoleManager;
import me.chachoox.sexmaster.manager.TotemPopManager;
import me.chachoox.sexmaster.manager.ReloadManager;
import me.chachoox.sexmaster.manager.PacketManager;
import me.chachoox.sexmaster.manager.TimerManager;
import me.chachoox.sexmaster.manager.InventoryManager;
import me.chachoox.sexmaster.manager.PotionManager;
import me.chachoox.sexmaster.manager.ServerManager;
import me.chachoox.sexmaster.manager.ColorManager;
import me.chachoox.sexmaster.manager.TextManager;
import me.chachoox.sexmaster.manager.FriendManager;
import me.chachoox.sexmaster.manager.FileManager;
import me.chachoox.sexmaster.manager.ConfigManager;
import me.chachoox.sexmaster.manager.EventManager;
import me.chachoox.sexmaster.manager.CommandManager;
import me.chachoox.sexmaster.manager.RotationManager;
import me.chachoox.sexmaster.manager.PositionManager;
import me.chachoox.sexmaster.manager.SpeedManager;
import me.chachoox.sexmaster.manager.ModuleManager;
import org.apache.logging.log4j.Logger;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "sexmaster", name = "SexMaster.CC", version = "1.4.2")
public class SexMaster
{
    public static final String MODID = "sexmaster";
    public static final String MODNAME = "SexMaster.CC";
    public static final String MODVER = "1.4.2";
    public static final Logger LOGGER;
    private static String name;
    public static ModuleManager moduleManager;
    public static SpeedManager speedManager;
    public static PositionManager positionManager;
    public static RotationManager rotationManager;
    public static CommandManager commandManager;
    public static EventManager eventManager;
    public static ConfigManager configManager;
    public static FileManager fileManager;
    public static FriendManager friendManager;
    public static TextManager textManager;
    public static ColorManager colorManager;
    public static ServerManager serverManager;
    public static PotionManager potionManager;
    public static InventoryManager inventoryManager;
    public static TimerManager timerManager;
    public static PacketManager packetManager;
    public static ReloadManager reloadManager;
    public static TotemPopManager totemPopManager;
    public static HoleManager holeManager;
    public static SafetyManager safetyManager;
    @Mod.Instance
    public static SexMaster INSTANCE;
    private static boolean unloaded;
    
    public static String getName() {
        return SexMaster.name;
    }
    
    public static void setName(final String newName) {
        SexMaster.name = newName;
    }
    
    public static void load() {
        SexMaster.LOGGER.info("\n\nLoading SexMaster.CC 1.4.2");
        SexMaster.unloaded = false;
        if (SexMaster.reloadManager != null) {
            SexMaster.reloadManager.unload();
            SexMaster.reloadManager = null;
        }
        SexMaster.totemPopManager = new TotemPopManager();
        SexMaster.timerManager = new TimerManager();
        SexMaster.packetManager = new PacketManager();
        SexMaster.serverManager = new ServerManager();
        SexMaster.colorManager = new ColorManager();
        SexMaster.textManager = new TextManager();
        SexMaster.moduleManager = new ModuleManager();
        SexMaster.speedManager = new SpeedManager();
        SexMaster.rotationManager = new RotationManager();
        SexMaster.positionManager = new PositionManager();
        SexMaster.commandManager = new CommandManager();
        SexMaster.eventManager = new EventManager();
        SexMaster.configManager = new ConfigManager();
        SexMaster.fileManager = new FileManager();
        SexMaster.friendManager = new FriendManager();
        SexMaster.potionManager = new PotionManager();
        SexMaster.inventoryManager = new InventoryManager();
        SexMaster.holeManager = new HoleManager();
        SexMaster.safetyManager = new SafetyManager();
        SexMaster.LOGGER.info("Initialized Managers");
        SexMaster.moduleManager.init();
        SexMaster.LOGGER.info("Modules loaded.");
        SexMaster.configManager.init();
        SexMaster.eventManager.init();
        SexMaster.LOGGER.info("EventManager loaded.");
        SexMaster.textManager.init(true);
        SexMaster.moduleManager.onLoad();
        SexMaster.totemPopManager.init();
        SexMaster.timerManager.init();
        if (SexMaster.moduleManager.getModuleByClass(RPC.class).isEnabled()) {
            DiscordPresence.start();
        }
        SexMaster.LOGGER.info("SexMaster.CC initialized!\n");
    }
    
    public static void unload(final boolean unload) {
        SexMaster.LOGGER.info("\n\nUnloading SexMaster.CC 1.4.2");
        if (unload) {
            (SexMaster.reloadManager = new ReloadManager()).init((SexMaster.commandManager != null) ? SexMaster.commandManager.getPrefix() : ".");
        }
        onUnload();
        SexMaster.eventManager = null;
        SexMaster.holeManager = null;
        SexMaster.timerManager = null;
        SexMaster.moduleManager = null;
        SexMaster.totemPopManager = null;
        SexMaster.serverManager = null;
        SexMaster.colorManager = null;
        SexMaster.textManager = null;
        SexMaster.speedManager = null;
        SexMaster.rotationManager = null;
        SexMaster.positionManager = null;
        SexMaster.commandManager = null;
        SexMaster.configManager = null;
        SexMaster.fileManager = null;
        SexMaster.friendManager = null;
        SexMaster.potionManager = null;
        SexMaster.inventoryManager = null;
        SexMaster.safetyManager = null;
        SexMaster.LOGGER.info("SexMaster.CC unloaded!\n");
    }
    
    public static void reload() {
        unload(false);
        load();
    }
    
    public static void onUnload() {
        if (!SexMaster.unloaded) {
            SexMaster.eventManager.onUnload();
            SexMaster.moduleManager.onUnload();
            SexMaster.configManager.saveConfig(SexMaster.configManager.config.replaceFirst("SexMaster/", ""));
            SexMaster.moduleManager.onUnloadPost();
            SexMaster.timerManager.unload();
            SexMaster.unloaded = true;
        }
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent event) {
        SexMaster.LOGGER.info("i lov phobo");
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        Display.setTitle("SexMaster.CC - v.1.4.2");
        load();
    }
    
    static {
        LOGGER = LogManager.getLogger("SexMaster.CC");
        SexMaster.name = "SexMaster.CC";
        SexMaster.unloaded = false;
    }
}
