// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.asm.mixin.transformer;

class MixinPreProcessorAccessor extends MixinPreProcessorInterface
{
    public MixinPreProcessorAccessor(final MixinInfo mixin, final MixinInfo.MixinClassNode classNode) {
        super(mixin, classNode);
    }
}
