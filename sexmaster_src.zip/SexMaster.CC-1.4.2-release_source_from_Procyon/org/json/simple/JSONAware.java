// 
// Decompiled by Procyon v0.5.36
// 

package org.json.simple;

public interface JSONAware
{
    String toJSONString();
}
