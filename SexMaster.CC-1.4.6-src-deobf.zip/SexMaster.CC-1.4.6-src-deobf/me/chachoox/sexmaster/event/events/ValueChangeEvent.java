/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.event.events;

import me.chachoox.sexmaster.event.EventStage;
import me.chachoox.sexmaster.features.setting.Setting;

public class ValueChangeEvent
extends EventStage {
    public Setting setting;
    public Object value;

    public ValueChangeEvent(Setting setting, Object value) {
        this.setting = setting;
        this.value = value;
    }
}

