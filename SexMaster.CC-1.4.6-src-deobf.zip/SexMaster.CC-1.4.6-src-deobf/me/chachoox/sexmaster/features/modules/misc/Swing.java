//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.util.EnumHand
 */
package me.chachoox.sexmaster.features.modules.misc;

import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.setting.Setting;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;

public class Swing
extends Module {
    private final Setting<Mode> swing = this.register(new Setting<Mode>("Swing", Mode.MAINHAND));
    private final Setting<Boolean> oldSwing = this.register(new Setting<Boolean>("OldSwing", false));
    public final Setting<Boolean> changeSwing = this.register(new Setting<Boolean>("ChangeSwing", false));
    public final Setting<Integer> swingDelay = this.register(new Setting<Integer>("SwingSpeed", Integer.valueOf(6), Integer.valueOf(1), Integer.valueOf(20), v -> this.changeSwing.getValue()));
    public static Swing INSTANCE;

    public Swing() {
        super("Swing", "Change animations.", Module.Category.MISC, true, false, false);
        this.setInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public static Swing getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Swing();
        }
        return INSTANCE;
    }

    @Override
    public void onUpdate() {
        if (Swing.nullCheck()) {
            return;
        }
        if (this.swing.getValue() == Mode.OFFHAND) {
            Swing.mc.player.swingingHand = EnumHand.OFF_HAND;
        }
        if (this.swing.getValue() == Mode.MAINHAND) {
            Swing.mc.player.swingingHand = EnumHand.MAIN_HAND;
        }
        if (this.oldSwing.getValue().booleanValue() && (double)Swing.mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
            Swing.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            Swing.mc.entityRenderer.itemRenderer.itemStackMainHand = Swing.mc.player.getHeldItemMainhand();
        }
    }

    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketAnimation && this.swing.getValue() == Mode.DISABLE) {
            event.setCanceled(true);
        }
    }

    private static enum Mode {
        MAINHAND,
        OFFHAND,
        DISABLE;

    }
}

