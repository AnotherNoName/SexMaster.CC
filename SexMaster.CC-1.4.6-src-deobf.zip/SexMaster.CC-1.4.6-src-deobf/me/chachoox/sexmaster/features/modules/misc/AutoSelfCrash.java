/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.FMLCommonHandler
 */
package me.chachoox.sexmaster.features.modules.misc;

import me.chachoox.sexmaster.features.modules.Module;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class AutoSelfCrash
extends Module {
    public AutoSelfCrash() {
        super("AutoSelfCrash", "Skype simulator.", Module.Category.MISC, true, false, false);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.toggle();
        FMLCommonHandler.instance().exitJava(0, true);
    }
}

