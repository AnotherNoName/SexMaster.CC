//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemShulkerBox
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketCloseWindow
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 */
package me.chachoox.sexmaster.features.modules.misc;

import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.setting.Setting;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Dupe5B
extends Module {
    private Setting<Integer> dropCount = this.register(new Setting<Integer>("Drop Count", 1, 1, 60));
    public Setting<Boolean> shulkerCheck = this.register(new Setting<Boolean>("Shulker Check", false));
    public Setting<Boolean> dropAll = this.register(new Setting<Boolean>("Drop All", false));

    public Dupe5B() {
        super("Dupe5B", "Auto Dupe in 5b5t.org", Module.Category.MISC, true, false, false);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent event) {
        if (Dupe5B.mc.player.getHeldItem(EnumHand.MAIN_HAND).getCount() > 1 && (!this.shulkerCheck.getValue().booleanValue() || Dupe5B.mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemShulkerBox)) {
            mc.displayGuiScreen(null);
            mc.getConnection().sendPacket((Packet)new CPacketCloseWindow());
            for (int i = 0; i < this.dropCount.getValue(); ++i) {
                Dupe5B.mc.player.dropItem(false);
            }
            if (this.dropAll.getValue().booleanValue()) {
                Dupe5B.mc.player.dropItem(true);
            }
        }
    }
}

