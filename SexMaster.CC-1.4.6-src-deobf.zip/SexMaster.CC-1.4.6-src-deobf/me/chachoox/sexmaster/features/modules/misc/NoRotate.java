//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.eventbus.Subscribe
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 */
package me.chachoox.sexmaster.features.modules.misc;

import com.google.common.eventbus.Subscribe;
import me.chachoox.sexmaster.event.events.PacketEvent;
import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.mixin.mixins.accessors.ISPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook;

public class NoRotate
extends Module {
    public NoRotate() {
        super("NoRotate", "stop rotating.", Module.Category.MISC, true, false, false);
    }

    @Subscribe
    public void onPacket(PacketEvent.Receive event) {
        if (NoRotate.fullNullCheck()) {
            return;
        }
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            ISPacketPlayerPosLook packet = (ISPacketPlayerPosLook)event.getPacket();
            packet.setPitch(NoRotate.mc.player.rotationPitch);
            packet.setYaw(NoRotate.mc.player.rotationYaw);
        }
    }
}

