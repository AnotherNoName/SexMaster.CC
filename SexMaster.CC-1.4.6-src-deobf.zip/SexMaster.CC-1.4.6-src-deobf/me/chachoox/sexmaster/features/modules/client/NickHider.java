//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.features.modules.client;

import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.setting.Setting;

public class NickHider
extends Module {
    private static NickHider instance;
    public final Setting<Boolean> changeOwn = this.register(new Setting<Boolean>("MyName", true));
    public final Setting<String> ownName = this.register(new Setting<Object>("Name", "Name here...", v -> this.changeOwn.getValue()));
    private static StringBuffer name;

    public NickHider() {
        super("NickHider", "Hides your nick", Module.Category.CLIENT, false, false, false);
        instance = this;
    }

    public static NickHider getInstance() {
        if (instance == null) {
            instance = new NickHider();
        }
        return instance;
    }

    public static String getPlayerName() {
        if (NickHider.fullNullCheck()) {
            return mc.getSession().getUsername();
        }
        String name = NickHider.PlayerName();
        if (name == null || name.isEmpty()) {
            return mc.getSession().getUsername();
        }
        return name;
    }

    public static String PlayerName() {
        if (name == null) {
            return null;
        }
        return name.toString();
    }

    static {
        name = null;
    }
}

