/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.features.modules.client;

import me.chachoox.sexmaster.DiscordPresence;
import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.setting.Setting;

public class RPC
extends Module {
    public static RPC INSTANCE;
    public Setting<Boolean> showIP = this.register(new Setting<Boolean>("ShowIP", Boolean.valueOf(true), "Shows the server IP in your discord presence."));
    public Setting<String> state = this.register(new Setting<String>("State", "SexMaster 1.4.6", "Sets the state of the DiscordRPC."));

    public RPC() {
        super("RPC", "Discord rich presence", Module.Category.CLIENT, false, false, false);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        DiscordPresence.start();
    }

    @Override
    public void onDisable() {
        DiscordPresence.stop();
    }
}

