//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiConfirmOpenLink
 *  net.minecraft.client.gui.GuiControls
 *  net.minecraft.client.gui.GuiCustomizeSkin
 *  net.minecraft.client.gui.GuiGameOver
 *  net.minecraft.client.gui.GuiIngameMenu
 *  net.minecraft.client.gui.GuiOptions
 *  net.minecraft.client.gui.GuiScreenOptionsSounds
 *  net.minecraft.client.gui.GuiVideoSettings
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.gui.inventory.GuiEditSign
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.client.GuiModList
 */
package me.chachoox.sexmaster.features.modules.client;

import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.modules.client.ClickGui;
import me.chachoox.sexmaster.util.Util;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiConfirmOpenLink;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;

public class GuiBlur
extends Module
implements Util {
    public GuiBlur() {
        super("GUIBlur", "nigga", Module.Category.CLIENT, true, false, false);
    }

    @Override
    public void onDisable() {
        if (GuiBlur.mc.world != null) {
            GuiBlur.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
        }
    }

    @Override
    public void onUpdate() {
        if (GuiBlur.mc.world == null) {
            return;
        }
        if (!(ClickGui.getInstance().isEnabled() || GuiBlur.mc.currentScreen instanceof GuiContainer || GuiBlur.mc.currentScreen instanceof GuiChat || GuiBlur.mc.currentScreen instanceof GuiConfirmOpenLink || GuiBlur.mc.currentScreen instanceof GuiEditSign || GuiBlur.mc.currentScreen instanceof GuiGameOver || GuiBlur.mc.currentScreen instanceof GuiOptions || GuiBlur.mc.currentScreen instanceof GuiIngameMenu || GuiBlur.mc.currentScreen instanceof GuiVideoSettings || GuiBlur.mc.currentScreen instanceof GuiScreenOptionsSounds || GuiBlur.mc.currentScreen instanceof GuiControls || GuiBlur.mc.currentScreen instanceof GuiCustomizeSkin || GuiBlur.mc.currentScreen instanceof GuiModList)) {
            if (GuiBlur.mc.entityRenderer.getShaderGroup() == null) {
                return;
            }
            GuiBlur.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
            return;
        }
        if (OpenGlHelper.shadersSupported && mc.getRenderViewEntity() instanceof EntityPlayer) {
            if (GuiBlur.mc.entityRenderer.getShaderGroup() != null) {
                GuiBlur.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
            }
            try {
                GuiBlur.mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
                return;
            }
            catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
        if (GuiBlur.mc.entityRenderer.getShaderGroup() == null) {
            return;
        }
        if (GuiBlur.mc.currentScreen != null) {
            return;
        }
        GuiBlur.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
    }
}

