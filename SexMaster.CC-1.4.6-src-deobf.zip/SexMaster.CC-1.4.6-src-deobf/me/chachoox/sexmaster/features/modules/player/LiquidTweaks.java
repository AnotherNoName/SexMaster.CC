//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.features.modules.player;

import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.setting.Setting;

public class LiquidTweaks
extends Module {
    private static LiquidTweaks INSTANCE = new LiquidTweaks();
    private final Setting<Boolean> vertical = this.register(new Setting<Boolean>("Vertical", false));
    private final Setting<Boolean> weird = this.register(new Setting<Boolean>("Always", false));

    public LiquidTweaks() {
        super("LiquidTweaks", "Changes Liquids interaction", Module.Category.PLAYER, false, false, false);
    }

    @Override
    public void onUpdate() {
        if (LiquidTweaks.mc.player.isInLava() && !this.weird.getValue().booleanValue() && this.vertical.getValue().booleanValue()) {
            if (!LiquidTweaks.mc.player.collidedVertically) {
                if (LiquidTweaks.mc.gameSettings.keyBindSneak.isKeyDown()) {
                    LiquidTweaks.mc.player.motionY -= 0.06553;
                }
            }
        }
    }
}

