/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.features.command.commands;

import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.command.Command;

public class ReloadCommand
extends Command {
    public ReloadCommand() {
        super("reload", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        SexMaster.reload();
    }
}

