/*
 * Decompiled with CFR 0.150.
 */
package me.chachoox.sexmaster.features.command.commands;

import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.command.Command;

public class HelpCommand
extends Command {
    public HelpCommand() {
        super("commands");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("You can use following commands: ");
        for (Command command : SexMaster.commandManager.getCommands()) {
            HelpCommand.sendMessage(SexMaster.commandManager.getPrefix() + command.getName());
        }
    }
}

