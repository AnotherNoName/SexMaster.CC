//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ServerData
 *  net.minecraft.client.network.ServerPinger
 */
package me.chachoox.sexmaster.mixin.mixins;

import java.net.UnknownHostException;
import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.modules.player.AntiDDoS;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.ServerPinger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ServerPinger.class})
public class MixinServerPinger {
    @Inject(method={"ping"}, at={@At(value="HEAD")}, cancellable=true)
    public void pingHook(ServerData server, CallbackInfo info) throws UnknownHostException {
        if (AntiDDoS.getInstance().shouldntPing(server.serverIP)) {
            SexMaster.LOGGER.info("AntiDDoS preventing Ping to: " + server.serverIP);
            info.cancel();
        }
    }

    @Inject(method={"tryCompatibilityPing"}, at={@At(value="HEAD")}, cancellable=true)
    public void tryCompatibilityPingHook(ServerData server, CallbackInfo info) {
        if (AntiDDoS.getInstance().shouldntPing(server.serverIP)) {
            SexMaster.LOGGER.info("AntiDDoS preventing Compatibility Ping to: " + server.serverIP);
            info.cancel();
        }
    }
}

