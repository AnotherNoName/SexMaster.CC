/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.biome.Biome$BiomeProperties
 */
package me.chachoox.sexmaster.mixin.mixins;

import net.minecraft.world.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={Biome.BiomeProperties.class})
public class MixinBiomeProperties {
}

