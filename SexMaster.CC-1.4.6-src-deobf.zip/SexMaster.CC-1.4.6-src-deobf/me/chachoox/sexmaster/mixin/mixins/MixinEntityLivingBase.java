/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityLivingBase
 */
package me.chachoox.sexmaster.mixin.mixins;

import me.chachoox.sexmaster.SexMaster;
import me.chachoox.sexmaster.features.modules.misc.Swing;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EntityLivingBase.class})
public class MixinEntityLivingBase {
    @Inject(method={"getArmSwingAnimationEnd"}, at={@At(value="HEAD")}, cancellable=true)
    private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> info) {
        if (SexMaster.moduleManager.isModuleEnabled("Swing") && Swing.INSTANCE.changeSwing.getValue().booleanValue()) {
            info.setReturnValue(Swing.INSTANCE.swingDelay.getValue());
        }
    }
}

