//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.EventBus
 *  org.lwjgl.input.Keyboard
 */
package me.chachoox.sexmaster.manager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.chachoox.sexmaster.event.events.Render2DEvent;
import me.chachoox.sexmaster.event.events.Render3DEvent;
import me.chachoox.sexmaster.features.Feature;
import me.chachoox.sexmaster.features.gui.SexMasterGui;
import me.chachoox.sexmaster.features.modules.Module;
import me.chachoox.sexmaster.features.modules.client.ClickGui;
import me.chachoox.sexmaster.features.modules.client.Colors;
import me.chachoox.sexmaster.features.modules.client.FontMod;
import me.chachoox.sexmaster.features.modules.client.GuiBlur;
import me.chachoox.sexmaster.features.modules.client.HUD;
import me.chachoox.sexmaster.features.modules.client.Managers;
import me.chachoox.sexmaster.features.modules.client.NickHider;
import me.chachoox.sexmaster.features.modules.client.Notifications;
import me.chachoox.sexmaster.features.modules.client.RPC;
import me.chachoox.sexmaster.features.modules.combat.AutoArmor;
import me.chachoox.sexmaster.features.modules.combat.AutoCrystal;
import me.chachoox.sexmaster.features.modules.combat.AutoTrap;
import me.chachoox.sexmaster.features.modules.combat.BowHack;
import me.chachoox.sexmaster.features.modules.combat.BowSpam;
import me.chachoox.sexmaster.features.modules.combat.Criticals;
import me.chachoox.sexmaster.features.modules.combat.GodModule;
import me.chachoox.sexmaster.features.modules.combat.HoleFiller;
import me.chachoox.sexmaster.features.modules.combat.Killaura;
import me.chachoox.sexmaster.features.modules.combat.NewOffhand;
import me.chachoox.sexmaster.features.modules.combat.Offhand;
import me.chachoox.sexmaster.features.modules.combat.Quiver;
import me.chachoox.sexmaster.features.modules.combat.Selftrap;
import me.chachoox.sexmaster.features.modules.combat.Surround;
import me.chachoox.sexmaster.features.modules.misc.AutoKit;
import me.chachoox.sexmaster.features.modules.misc.AutoSelfCrash;
import me.chachoox.sexmaster.features.modules.misc.BetterPortals;
import me.chachoox.sexmaster.features.modules.misc.BuildHeight;
import me.chachoox.sexmaster.features.modules.misc.ChatModifier;
import me.chachoox.sexmaster.features.modules.misc.ChorusPredict;
import me.chachoox.sexmaster.features.modules.misc.Dupe5B;
import me.chachoox.sexmaster.features.modules.misc.EntityNotifier;
import me.chachoox.sexmaster.features.modules.misc.KitDelete;
import me.chachoox.sexmaster.features.modules.misc.MCF;
import me.chachoox.sexmaster.features.modules.misc.NoEntityTrace;
import me.chachoox.sexmaster.features.modules.misc.NoRotate;
import me.chachoox.sexmaster.features.modules.misc.Swing;
import me.chachoox.sexmaster.features.modules.misc.ToolTips;
import me.chachoox.sexmaster.features.modules.misc.Tracker;
import me.chachoox.sexmaster.features.modules.movement.Anchor;
import me.chachoox.sexmaster.features.modules.movement.AntiVoid;
import me.chachoox.sexmaster.features.modules.movement.AntiWeb;
import me.chachoox.sexmaster.features.modules.movement.Burrow;
import me.chachoox.sexmaster.features.modules.movement.NoSlowDown;
import me.chachoox.sexmaster.features.modules.movement.PacketFly;
import me.chachoox.sexmaster.features.modules.movement.ReverseStep;
import me.chachoox.sexmaster.features.modules.movement.Scaffold;
import me.chachoox.sexmaster.features.modules.movement.Speed;
import me.chachoox.sexmaster.features.modules.movement.Sprint;
import me.chachoox.sexmaster.features.modules.movement.Step;
import me.chachoox.sexmaster.features.modules.movement.Strafe;
import me.chachoox.sexmaster.features.modules.movement.Velocity;
import me.chachoox.sexmaster.features.modules.player.AntiDDoS;
import me.chachoox.sexmaster.features.modules.player.FakePlayer;
import me.chachoox.sexmaster.features.modules.player.FastPlace;
import me.chachoox.sexmaster.features.modules.player.Freecam;
import me.chachoox.sexmaster.features.modules.player.LiquidInteract;
import me.chachoox.sexmaster.features.modules.player.LiquidTweaks;
import me.chachoox.sexmaster.features.modules.player.MCP;
import me.chachoox.sexmaster.features.modules.player.MultiTask;
import me.chachoox.sexmaster.features.modules.player.Replenish;
import me.chachoox.sexmaster.features.modules.player.SilentXP;
import me.chachoox.sexmaster.features.modules.player.Speedmine;
import me.chachoox.sexmaster.features.modules.player.TimerSpeed;
import me.chachoox.sexmaster.features.modules.player.XCarry;
import me.chachoox.sexmaster.features.modules.render.Aspect;
import me.chachoox.sexmaster.features.modules.render.BlockHighlight;
import me.chachoox.sexmaster.features.modules.render.BurrowESP;
import me.chachoox.sexmaster.features.modules.render.Crosshair;
import me.chachoox.sexmaster.features.modules.render.CrystalChams;
import me.chachoox.sexmaster.features.modules.render.ESP;
import me.chachoox.sexmaster.features.modules.render.EnchantColor;
import me.chachoox.sexmaster.features.modules.render.Fullbright;
import me.chachoox.sexmaster.features.modules.render.HoleESP;
import me.chachoox.sexmaster.features.modules.render.LogoutSpots;
import me.chachoox.sexmaster.features.modules.render.Nametags;
import me.chachoox.sexmaster.features.modules.render.NoRender;
import me.chachoox.sexmaster.features.modules.render.PenisESP;
import me.chachoox.sexmaster.features.modules.render.ViewModel;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.lwjgl.input.Keyboard;

public class ModuleManager
extends Feature {
    public ArrayList<Module> modules = new ArrayList();
    public List<Module> sortedModules = new ArrayList<Module>();
    public List<Module> alphabeticallySortedModules = new ArrayList<Module>();

    public void init() {
        this.modules.add(new Offhand());
        this.modules.add(new Surround());
        this.modules.add(new AutoTrap());
        this.modules.add(new AutoCrystal());
        this.modules.add(new Criticals());
        this.modules.add(new Killaura());
        this.modules.add(new HoleFiller());
        this.modules.add(new Selftrap());
        this.modules.add(new AutoArmor());
        this.modules.add(new GodModule());
        this.modules.add(new ChatModifier());
        this.modules.add(new BetterPortals());
        this.modules.add(new BuildHeight());
        this.modules.add(new MCF());
        this.modules.add(new KitDelete());
        this.modules.add(new Tracker());
        this.modules.add(new RPC());
        this.modules.add(new ReverseStep());
        this.modules.add(new Strafe());
        this.modules.add(new Velocity());
        this.modules.add(new Speed());
        this.modules.add(new Step());
        this.modules.add(new Sprint());
        this.modules.add(new PacketFly());
        this.modules.add(new LiquidTweaks());
        this.modules.add(new FakePlayer());
        this.modules.add(new TimerSpeed());
        this.modules.add(new FastPlace());
        this.modules.add(new Freecam());
        this.modules.add(new Speedmine());
        this.modules.add(new XCarry());
        this.modules.add(new Replenish());
        this.modules.add(new MCP());
        this.modules.add(new AntiDDoS());
        this.modules.add(new NoRender());
        this.modules.add(new ESP());
        this.modules.add(new HoleESP());
        this.modules.add(new BlockHighlight());
        this.modules.add(new CrystalChams());
        this.modules.add(new Notifications());
        this.modules.add(new HUD());
        this.modules.add(new ToolTips());
        this.modules.add(new FontMod());
        this.modules.add(new ClickGui());
        this.modules.add(new Managers());
        this.modules.add(new Colors());
        this.modules.add(new NickHider());
        this.modules.add(new Anchor());
        this.modules.add(new GuiBlur());
        this.modules.add(new AntiWeb());
        this.modules.add(new BurrowESP());
        this.modules.add(new AutoKit());
        this.modules.add(new Aspect());
        this.modules.add(new EnchantColor());
        this.modules.add(new Burrow());
        this.modules.add(new NewOffhand());
        this.modules.add(new AntiVoid());
        this.modules.add(new NoRotate());
        this.modules.add(new Scaffold());
        this.modules.add(new ViewModel());
        this.modules.add(new NoSlowDown());
        this.modules.add(new MultiTask());
        this.modules.add(new BowSpam());
        this.modules.add(new SilentXP());
        this.modules.add(new NoEntityTrace());
        this.modules.add(new EntityNotifier());
        this.modules.add(new PenisESP());
        this.modules.add(new Nametags());
        this.modules.add(new ChorusPredict());
        this.modules.add(new Quiver());
        this.modules.add(new LogoutSpots());
        this.modules.add(new Fullbright());
        this.modules.add(new Swing());
        this.modules.add(new BowHack());
        this.modules.add(new LiquidInteract());
        this.modules.add(new AutoSelfCrash());
        this.modules.add(new Dupe5B());
        this.modules.add(new Crosshair());
        for (Module module : this.modules) {
            module.animation.start();
        }
    }

    public <T extends Module> T getModuleT(Class<T> clazz) {
        return (T)((Module)this.modules.stream().filter(module -> module.getClass() == clazz).map(module -> module).findFirst().orElse(null));
    }

    public Module getModuleByName(String name) {
        for (Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public <T extends Module> T getModuleByClass(Class<T> clazz) {
        for (Module module : this.modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)module;
        }
        return null;
    }

    public void enableModule(Class clazz) {
        Object module = this.getModuleByClass(clazz);
        if (module != null) {
            ((Module)module).enable();
        }
    }

    public void disableModule(Class clazz) {
        Object module = this.getModuleByClass(clazz);
        if (module != null) {
            ((Module)module).disable();
        }
    }

    public void enableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.enable();
        }
    }

    public void disableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.disable();
        }
    }

    public boolean isModuleEnabled(String name) {
        Module module = this.getModuleByName(name);
        return module != null && module.isOn();
    }

    public boolean isModuleEnabled(Class clazz) {
        Object module = this.getModuleByClass(clazz);
        return module != null && ((Module)module).isOn();
    }

    public Module getModuleByDisplayName(String displayName) {
        for (Module module : this.modules) {
            if (!module.getDisplayName().equalsIgnoreCase(displayName)) continue;
            return module;
        }
        return null;
    }

    public ArrayList<Module> getEnabledModules() {
        ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (Module module : this.modules) {
            if (!module.isEnabled() && !module.isSliding()) continue;
            enabledModules.add(module);
        }
        return enabledModules;
    }

    public ArrayList<Module> getModulesByCategory(Module.Category category) {
        ArrayList<Module> modulesCategory = new ArrayList<Module>();
        this.modules.forEach(module -> {
            if (module.getCategory() == category) {
                modulesCategory.add((Module)module);
            }
        });
        return modulesCategory;
    }

    public List<Module.Category> getCategories() {
        return Arrays.asList(Module.Category.values());
    }

    public void onLoad() {
        this.modules.stream().filter(Module::listening).forEach(((EventBus)MinecraftForge.EVENT_BUS)::register);
        this.modules.forEach(Module::onLoad);
    }

    public void onUpdate() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
    }

    public void onTick() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
    }

    public void onRender2D(Render2DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
    }

    public void onRender3D(Render3DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
    }

    public void sortModules(boolean reverse) {
        this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1))).collect(Collectors.toList());
    }

    public void alphabeticallySortModules() {
        this.alphabeticallySortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(Module::getDisplayName)).collect(Collectors.toList());
    }

    public void onLogout() {
        this.modules.forEach(Module::onLogout);
    }

    public void onLogin() {
        this.modules.forEach(Module::onLogin);
    }

    public void onUnload() {
        this.modules.forEach(((EventBus)MinecraftForge.EVENT_BUS)::unregister);
        this.modules.forEach(Module::onUnload);
    }

    public void onUnloadPost() {
        for (Module module : this.modules) {
            module.enabled.setValue(false);
        }
    }

    public void onKeyPressed(int eventKey) {
        if (eventKey == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.currentScreen instanceof SexMasterGui) {
            return;
        }
        this.modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey) {
                module.toggle();
            }
        });
    }

    public List<Module> getAnimationModules(Module.Category category) {
        ArrayList<Module> animationModules = new ArrayList<Module>();
        for (Module module : this.getEnabledModules()) {
            if (module.getCategory() != category || module.isDisabled() || !module.isSliding() || !module.isDrawn()) continue;
            animationModules.add(module);
        }
        return animationModules;
    }
}

