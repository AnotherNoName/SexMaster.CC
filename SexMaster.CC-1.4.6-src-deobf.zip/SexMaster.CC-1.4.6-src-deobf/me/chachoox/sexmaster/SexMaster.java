/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.Mod$Instance
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.opengl.Display
 */
package me.chachoox.sexmaster;

import me.chachoox.sexmaster.DiscordPresence;
import me.chachoox.sexmaster.features.modules.client.RPC;
import me.chachoox.sexmaster.manager.ColorManager;
import me.chachoox.sexmaster.manager.CommandManager;
import me.chachoox.sexmaster.manager.ConfigManager;
import me.chachoox.sexmaster.manager.EventManager;
import me.chachoox.sexmaster.manager.FileManager;
import me.chachoox.sexmaster.manager.FriendManager;
import me.chachoox.sexmaster.manager.HoleManager;
import me.chachoox.sexmaster.manager.InventoryManager;
import me.chachoox.sexmaster.manager.ModuleManager;
import me.chachoox.sexmaster.manager.PacketManager;
import me.chachoox.sexmaster.manager.PositionManager;
import me.chachoox.sexmaster.manager.PotionManager;
import me.chachoox.sexmaster.manager.ReloadManager;
import me.chachoox.sexmaster.manager.RotationManager;
import me.chachoox.sexmaster.manager.SafetyManager;
import me.chachoox.sexmaster.manager.ServerManager;
import me.chachoox.sexmaster.manager.SpeedManager;
import me.chachoox.sexmaster.manager.TextManager;
import me.chachoox.sexmaster.manager.TimerManager;
import me.chachoox.sexmaster.manager.TotemPopManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

@Mod(modid="sexmaster", name="SexMaster.CC", version="1.4.6")
public class SexMaster {
    public static final String MODID = "sexmaster";
    public static final String MODNAME = "SexMaster.CC";
    public static final String MODVER = "1.4.6";
    public static final Logger LOGGER = LogManager.getLogger((String)"SexMaster.CC");
    private static String name = "SexMaster.CC";
    public static ModuleManager moduleManager;
    public static SpeedManager speedManager;
    public static PositionManager positionManager;
    public static RotationManager rotationManager;
    public static CommandManager commandManager;
    public static EventManager eventManager;
    public static ConfigManager configManager;
    public static FileManager fileManager;
    public static FriendManager friendManager;
    public static TextManager textManager;
    public static ColorManager colorManager;
    public static ServerManager serverManager;
    public static PotionManager potionManager;
    public static InventoryManager inventoryManager;
    public static TimerManager timerManager;
    public static PacketManager packetManager;
    public static ReloadManager reloadManager;
    public static TotemPopManager totemPopManager;
    public static HoleManager holeManager;
    public static SafetyManager safetyManager;
    @Mod.Instance
    public static SexMaster INSTANCE;
    private static boolean unloaded;

    public static String getName() {
        return name;
    }

    public static void setName(String newName) {
        name = newName;
    }

    public static void load() {
        LOGGER.info("\n\nLoading SexMaster.CC 1.4.6");
        unloaded = false;
        if (reloadManager != null) {
            reloadManager.unload();
            reloadManager = null;
        }
        totemPopManager = new TotemPopManager();
        timerManager = new TimerManager();
        packetManager = new PacketManager();
        serverManager = new ServerManager();
        colorManager = new ColorManager();
        textManager = new TextManager();
        moduleManager = new ModuleManager();
        speedManager = new SpeedManager();
        rotationManager = new RotationManager();
        positionManager = new PositionManager();
        commandManager = new CommandManager();
        eventManager = new EventManager();
        configManager = new ConfigManager();
        fileManager = new FileManager();
        friendManager = new FriendManager();
        potionManager = new PotionManager();
        inventoryManager = new InventoryManager();
        holeManager = new HoleManager();
        safetyManager = new SafetyManager();
        LOGGER.info("Initialized Managers");
        moduleManager.init();
        LOGGER.info("Modules loaded.");
        configManager.init();
        eventManager.init();
        LOGGER.info("EventManager loaded.");
        textManager.init(true);
        moduleManager.onLoad();
        totemPopManager.init();
        timerManager.init();
        if (moduleManager.getModuleByClass(RPC.class).isEnabled()) {
            DiscordPresence.start();
        }
        LOGGER.info("SexMaster.CC initialized!\n");
    }

    public static void unload(boolean unload) {
        LOGGER.info("\n\nUnloading SexMaster.CC 1.4.6");
        if (unload) {
            reloadManager = new ReloadManager();
            reloadManager.init(commandManager != null ? commandManager.getPrefix() : ".");
        }
        SexMaster.onUnload();
        eventManager = null;
        holeManager = null;
        timerManager = null;
        moduleManager = null;
        totemPopManager = null;
        serverManager = null;
        colorManager = null;
        textManager = null;
        speedManager = null;
        rotationManager = null;
        positionManager = null;
        commandManager = null;
        configManager = null;
        fileManager = null;
        friendManager = null;
        potionManager = null;
        inventoryManager = null;
        safetyManager = null;
        LOGGER.info("SexMaster.CC unloaded!\n");
    }

    public static void reload() {
        SexMaster.unload(false);
        SexMaster.load();
    }

    public static void onUnload() {
        if (!unloaded) {
            eventManager.onUnload();
            moduleManager.onUnload();
            configManager.saveConfig(SexMaster.configManager.config.replaceFirst("SexMaster/", ""));
            moduleManager.onUnloadPost();
            timerManager.unload();
            unloaded = true;
        }
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER.info("i lov phobo");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Display.setTitle((String)"SexMaster.CC - v.1.4.6");
        SexMaster.load();
    }

    static {
        unloaded = false;
    }
}

