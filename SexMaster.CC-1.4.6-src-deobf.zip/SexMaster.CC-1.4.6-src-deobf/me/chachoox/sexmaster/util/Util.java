//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package me.chachoox.sexmaster.util;

import net.minecraft.client.Minecraft;

public interface Util {
    public static final Minecraft mc = Minecraft.getMinecraft();
}

