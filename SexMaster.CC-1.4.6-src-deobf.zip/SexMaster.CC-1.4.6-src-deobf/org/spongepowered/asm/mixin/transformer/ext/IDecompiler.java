/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.asm.mixin.transformer.ext;

import java.io.File;

public interface IDecompiler {
    public void decompile(File var1);
}

