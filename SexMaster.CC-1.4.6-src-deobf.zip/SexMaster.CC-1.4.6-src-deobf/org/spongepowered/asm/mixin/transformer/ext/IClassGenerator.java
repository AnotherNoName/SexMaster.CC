/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.asm.mixin.transformer.ext;

public interface IClassGenerator {
    public byte[] generate(String var1);
}

